const express = require("express");
const cors = require("cors");
const stripe = require("stripe")(
  "sk_test_51P2FrVRxtMIfYHGVHsANuSOsWDyRutmSBkuEy215Q6G6htFXR9WQlmgPfejhYophKhyYZitF085nyJzO0DgK8XMa00Xc3jYIpv"
); // Replace with your Stripe secret key

const app = express();
app.use(cors());
app.use(express.json()); // Middleware to parse JSON request bodies

const PORT = 3000;

app.post("/create-checkout-session", async (req, res) => {
  try {
    const { amount } = req.body; // Amount in cents
    const amountInCents = Math.round(amount * 100);

    // Create a Checkout Session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: "Your Product Name",
            },
            unit_amount: amountInCents, // Amount in cents
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: "http://localhost:3001/success", // Replace with your success page URL
      cancel_url: "http://localhost:3001/user-cart", // Replace with your cancel page URL
    });

    // Send the URL to redirect the user
    res.send({ url: session.url });
  } catch (error) {
    console.error("Error creating Checkout Session:", error);
    res.status(500).send({ error: error.message });
  }
});

app.get("/", async (req, res) => {
  console.log("hello world");
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
