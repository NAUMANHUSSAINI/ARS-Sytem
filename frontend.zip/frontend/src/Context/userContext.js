import React, { createContext, useContext, useState } from "react";

// Create a context
export const MyContext = createContext();

// Create a custom provider component
export const MyContextProvider = ({ children }) => {
  const [value, setValue] = useState("CREATIVE");
  const [userId, setuserId] = useState("");

  return (
    <MyContext.Provider
      value={{
        value,
        setValue,
        userId,
        setuserId,
      }}
    >
      {children}
    </MyContext.Provider>
  );
};
