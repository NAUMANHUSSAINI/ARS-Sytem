import React, { useState } from "react";
import Layout from "../../Components/Layout/Layout";
import Stripe from "../../Components/Common/Stripe";
import QuickAddress from "../../Components/Common/QuickAddress";
import { Box, Button, Container, Grid, Typography } from "@mui/material";
import { sendContactForm } from "../../Components/Services/PostServices";
import toast from "react-hot-toast";

const ConactForm = () => {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    subject: "",
    message: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    sendContactForm(formData).then((data) => {
      toast.success("Form Submitted");
      setFormData({
        fullName: "",
        email: "",
        subject: "",
        message: "",
      });
    });
  };
  return (
    <>
      <Box sx={{ paddingY: "50px" }}>
        <Container sx={style.container}>
          <Typography
            sx={style.heading}
            data-aos="fade-up"
            data-aos-delay="500"
          >
            Send us a messages
          </Typography>
          <Typography
            data-aos="fade-up"
            data-aos-delay="700"
            sx={{ fontSize: "17px", fontFamily: "Poppins", opacity: 0.7 }}
          >
            Aenean a turpis finibus euismod augue et facilisis elit. In sed quam
            et dui.
          </Typography>
          <Grid container spacing={4} sx={{ marginTop: "30px" }}>
            <Grid item lg={6}>
              <iframe
                title="Google Map"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3619.692898806654!2d67.08133167595254!3d24.87433624470119!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb33eb0c233c937%3A0xece293c5c3aca774!2sTipu%20Sultan%20Rd%2C%20Karachi%2C%20Karachi%20City%2C%20Sindh%2C%20Pakistan!5e0!3m2!1sen!2s!4v1713199232005!5m2!1sen!2s"
                width="600"
                height="450"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </Grid>
            <Grid item lg={6}>
              <Box sx={style.form}>
                <input
                  className="input-grey-rounded-contact"
                  type="text"
                  placeholder="Enter Full Name..."
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleChange}
                />
                <input
                  className="input-grey-rounded-contact"
                  type="text"
                  placeholder="Email..."
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                />
                <input
                  className="input-grey-rounded-contact"
                  type="text"
                  placeholder="Subject..."
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                />
                <input
                  className="input-grey-rounded-contact-message"
                  type="text"
                  placeholder="Message..."
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                />
                <Button
                  onClick={handleSubmit}
                  variant="outlined"
                  sx={style.btn}
                >
                  SUBMIT
                </Button>
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </>
  );
};

const ContactUs = () => {
  return (
    <Layout>
      <Stripe word={"CONTACT US"} />
      <QuickAddress />
      <ConactForm />
    </Layout>
  );
};

export default ContactUs;
const style = {
  container: {
    maxWidth: { lg: "1450px" },
  },
  heading: {
    fontSize: { sm: "40px", xs: "25px" },
    fontFamily: "Poppins",
    paddingTop: { sm: "2rem", xs: "1rem" },
    fontWeight: 700,
  },
  form: {
    padding: "20px",
    dislpay: "flex",
    flexDirection: "column",
    gap: "10px",
  },
  btn: {
    fontWeight: 600,
    fontFamily: "Poppins",
    fontSize: "18px",
    border: "1px solid #EF8132",
    borderRadius: "5px",
    transition: "all ease-out 0.5s",
    color: "black",
    backgroundColor: "#EF8132",
    color: "white",
    boxShadow: 15,
    boxShadow: 1,
    width: "100%",
    ":hover": {
      backgroundColor: "black",
      border: "1px solid black",
      color: "white",
    },
  },
};
