import React, { useContext, useState } from "react";
import Layout from "../../Components/Layout/Layout";
import { Box, Button, Container, Typography, TextField } from "@mui/material";
import logo from "../../Assets/logoWN.png";
import { Link, useNavigate } from "react-router-dom";
import { FaEye } from "react-icons/fa";
import { FaRegEyeSlash } from "react-icons/fa";
import { signUpWithEmailAndPassword } from "../../Components/Services/AuthServices";
import toast from "react-hot-toast";
import { MyContext } from "../../Context/userContext";

const intitial = {
  name: "",
  email: "",
  password: "",
  ConfrmPassword: "",
  address: "",
  postalCode: "",
};

const Register = () => {
  const navigate = useNavigate();
  const { setuserId } = useContext(MyContext);
  const [formData, setFormData] = useState(intitial);
  const [show, setShow] = useState(false);
  const [errors, seterror] = useState({});

  const { name, email, password, ConfrmPassword, address, postalCode } =
    formData;

  const handleChange = (key, value) => {
    setFormData((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  function validateFormData(formData) {
    const errors = {};

    // Validate Name
    if (!name || name.trim() === "") {
      errors.name = "Name is required*";
    }

    // Validate Email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
      errors.email = "Please enter a valid email address*";
    }

    // Validate Password
    if (!password || password.length < 8) {
      errors.password = "Password must be at least 8 characters long*";
    }

    // Validate Confirm Password
    if (password !== ConfrmPassword) {
      errors.confirmPassword = "Passwords do not match*";
    }

    // Validate Address
    if (!address || address.trim() === "") {
      errors.address = "Address is required*";
    }

    // Validate Postal Code (assuming postal code is a simple alphanumeric string)
    const postalCodeRegex = /^[a-zA-Z0-9\s]*$/;
    if (!postalCode || !postalCodeRegex.test(postalCode)) {
      errors.postalCode = "Please enter a valid postal code*";
    }

    return errors;
  }

  // Usage example:

  const handleSubmit = () => {
    const errorss = validateFormData(formData);
    seterror(errorss);
    if (Object.keys(errors).length > 0) {
      console.log("Validation errors:", errors);
      return;
    } else {
      signUpWithEmailAndPassword(formData).then((data) => {
        setuserId(data);
        toast.success("User Created");
        navigate("/login");
      });
    }
  };

  return (
    <Layout>
      <Container sx={style.container}>
        <Box sx={style.loginBox}>
          <img
            src={logo}
            alt="oops"
            style={{ width: "100px", height: "100px" }}
          />
          <Typography sx={style.heading}>SIGN UP</Typography>
          <TextField
            placeholder="Full Name..."
            sx={{ width: { md: "50%", xs: "100%" } }}
            value={name}
            onChange={(e) => {
              handleChange("name", e.target.value);
            }}
            required
          />
          {errors && errors.name && (
            <Typography sx={{ color: "red", width: "100%", textAlign: "left" }}>
              {errors.name}
            </Typography>
          )}
          <TextField
            placeholder="Email..."
            sx={{ width: { md: "50%", xs: "100%" } }}
            value={email}
            onChange={(e) => {
              handleChange("email", e.target.value);
            }}
            required
          />
          {errors && errors.email && (
            <Typography sx={{ color: "red", width: "100%", textAlign: "left" }}>
              {errors.email}
            </Typography>
          )}
          <Box sx={{ position: "relative", width: { xs: "100%", md: "50%" } }}>
            <TextField
              type={show ? "text" : "Password"}
              placeholder="Password..."
              value={password}
              sx={{ width: "100%" }}
              onChange={(e) => {
                handleChange("password", e.target.value);
              }}
              required
            />
            {show ? (
              <FaEye
                onClick={() => {
                  setShow(false);
                }}
                style={{
                  position: "absolute",
                  right: 20,
                  zIndex: 99,
                  top: "30%",
                  fontSize: 20,
                }}
              />
            ) : (
              <FaRegEyeSlash
                onClick={() => {
                  setShow(true);
                }}
                style={{
                  position: "absolute",
                  right: 20,
                  zIndex: 99,
                  top: "30%",
                  fontSize: 20,
                }}
              />
            )}
          </Box>
          {errors && errors.password && (
            <Typography sx={{ color: "red", width: "100%", textAlign: "left" }}>
              {errors.password}
            </Typography>
          )}
          <Box sx={{ position: "relative", width: { xs: "100%", md: "50%" } }}>
            <TextField
              type={show ? "text" : "Password"}
              placeholder="Confirm Password..."
              sx={{ width: "100%" }}
              value={ConfrmPassword}
              onChange={(e) => {
                handleChange("ConfrmPassword", e.target.value);
              }}
              required
            />
            {show ? (
              <FaEye
                onClick={() => {
                  setShow(false);
                }}
                style={{
                  position: "absolute",
                  right: 20,
                  zIndex: 99,
                  top: "30%",
                  fontSize: 20,
                }}
              />
            ) : (
              <FaRegEyeSlash
                onClick={() => {
                  setShow(true);
                }}
                style={{
                  position: "absolute",
                  right: 20,
                  zIndex: 99,
                  top: "30%",
                  fontSize: 20,
                }}
              />
            )}
          </Box>
          {errors && errors.confirmPassword && (
            <Typography sx={{ color: "red", width: "100%", textAlign: "left" }}>
              {errors.confirmPassword}
            </Typography>
          )}
          <TextField
            placeholder="Address..."
            sx={{ width: { md: "50%", xs: "100%" } }}
            value={address}
            onChange={(e) => {
              handleChange("address", e.target.value);
            }}
            required
          />
          {errors && errors.address && (
            <Typography sx={{ color: "red", width: "100%", textAlign: "left" }}>
              {errors.address}
            </Typography>
          )}
          <TextField
            placeholder="Postal Code..."
            sx={{ width: { md: "50%", xs: "100%" } }}
            value={postalCode}
            onChange={(e) => {
              handleChange("postalCode", e.target.value);
            }}
            required
          />
          {errors && errors.postalCode && (
            <Typography sx={{ color: "red", width: "100%", textAlign: "left" }}>
              {errors.postalCode}
            </Typography>
          )}
          <Button sx={style.btnCheckout} onClick={handleSubmit}>
            SIGN UP
          </Button>
          <Typography sx={style.dontHaveAccout}>
            Already Have An Account ?
            <Link
              to={"/login"}
              style={{ textDecoration: "none", color: "inherit" }}
            >
              <span style={{ fontWeight: 600, marginLeft: 4 }}>Login</span>
            </Link>
          </Typography>
        </Box>
      </Container>
    </Layout>
  );
};

export default Register;
const style = {
  container: {
    maxWidth: { lg: "1450px" },
    marginY: "4rem",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  heading: {
    fontSize: 35,
    fontFamily: "Poppins",
    fontWeight: 700,
    paddingY: "1rem",
    opacity: 0.7,
  },
  loginBox: {
    width: "50%",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: "12px",
  },
  btnCheckout: {
    fontFamily: "Poppins",
    fontWeight: 600,
    color: "white",
    marginY: "15px",
    border: "1px solid grey",
    background: "black",
    transition: "all ease-out 0.5s",
    width: { xs: "100%", md: "50%" },
    paddingY: "8px",
    fontSize: 18,
    ":hover": {
      background: "white",
      color: "grey",
    },
  },
  dontHaveAccout: {
    fontFamily: "Poppins",
    color: "black",
    opacity: 0.9,
    fontSize: 17,
  },
};
