import React, { useContext, useState } from "react";
import Layout from "../../Components/Layout/Layout";
import { Box, Button, Container, TextField, Typography } from "@mui/material";
import logo from "../../Assets/logoWN.png";
import { FaEye } from "react-icons/fa";
import { FaRegEyeSlash } from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom";
import { SignIn } from "../../Components/Services/AuthServices";
import { useDispatch } from "react-redux";
import { setUser } from "../../Redux/User/UserSlice";

import toast from "react-hot-toast";
const intitial = {
  email: "",
  password: "",
};
const Login = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [formData, setFormData] = useState(intitial);
  const [show, setShow] = useState(false);
  const { email, password } = formData;
  const handleChange = (key, value) => {
    setFormData((prev) => ({
      ...prev,
      [key]: value,
    }));
  };
  const handleSubmit = () => {
    SignIn(formData).then((data) => {
      if (data) {
        dispatch(setUser(data));
        toast.success("Login Successfull");
        navigate("/");
      }
    });
  };
  return (
    <Layout>
      <Container sx={style.container}>
        <Box sx={style.loginBox}>
          <img
            src={logo}
            alt="oops"
            style={{ width: "100px", height: "100px" }}
          />
          <Typography sx={style.heading}>LOGIN</Typography>
          <TextField
            // className="form-control"
            placeholder="Email..."
            value={email}
            sx={{ width: { md: "50%", xs: "100%" } }}
            onChange={(e) => {
              handleChange("email", e.target.value);
            }}
          />
          <Box sx={{ position: "relative", width: { md: "50%", xs: "100%" } }}>
            <TextField
              // className="form-control"
              type={show ? "text" : "Password"}
              placeholder="Password..."
              value={password}
              sx={{ width: { xs: "100%" } }}
              onChange={(e) => {
                handleChange("password", e.target.value);
              }}
            />
            {show ? (
              <FaEye
                onClick={() => {
                  setShow(false);
                }}
                style={{
                  position: "absolute",
                  right: 20,
                  zIndex: 99,
                  top: "30%",
                  fontSize: 20,
                }}
              />
            ) : (
              <FaRegEyeSlash
                onClick={() => {
                  setShow(true);
                }}
                style={{
                  position: "absolute",
                  right: 20,
                  zIndex: 99,
                  top: "30%",
                  fontSize: 20,
                }}
              />
            )}
          </Box>

          <Typography
            sx={[
              style.dontHaveAccout,
              { textAlign: "right", width: { xs: "100%", md: "50%" } },
            ]}
          >
            Forget Password ?
          </Typography>
          <Button sx={style.btnCheckout} onClick={handleSubmit}>
            Login
          </Button>
          <Typography sx={style.dontHaveAccout}>
            Dont Have An Account ?
            <Link
              to={"/register"}
              style={{ textDecoration: "none", color: "inherit" }}
            >
              <span style={{ fontWeight: 600, marginLeft: 4 }}>Register</span>
            </Link>
          </Typography>
        </Box>
      </Container>
    </Layout>
  );
};

export default Login;
const style = {
  container: {
    maxWidth: { lg: "1450px" },
    marginY: "4rem",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  heading: {
    fontSize: 35,
    fontFamily: "Poppins",
    fontWeight: 700,
    paddingY: "1rem",
    opacity: 0.7,
  },
  loginBox: {
    width: "50%",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: "12px",
  },
  btnCheckout: {
    fontFamily: "Poppins",
    fontWeight: 600,
    color: "white",
    marginY: "15px",
    border: "1px solid grey",
    background: "black",
    transition: "all ease-out 0.5s",
    width: { xs: "100%", md: "50%" },
    paddingY: "8px",
    fontSize: 18,
    ":hover": {
      background: "white",
      color: "grey",
    },
  },
  dontHaveAccout: {
    fontFamily: "Poppins",
    color: "black",
    opacity: 0.9,
    fontSize: 17,
  },
};
