import React from "react";
import Layout from "../../Components/Layout/Layout";
import { Box, Button, Container, Grid, Typography } from "@mui/material";
import about from "../../Assets/ProductIImages/about.jpg";
import { Company } from "../../Components/Home/Company";
import TeamMembers from "../../Components/Common/TeamMembers";
import Stripe from "../../Components/Common/Stripe";

export const About = () => {
  return (
    <Layout>
      <Stripe word={"ABOUT US"} />
      <Container sx={style.container}>
        <Grid container spacing={5}>
          <Grid item lg={6} xs={12}>
            <Box
              sx={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <img
                data-aos="fade-right"
                data-aos-delay="900"
                src={about}
                alt="oops"
                style={{
                  width: "100%",
                  height: "auto",
                  objectFit: "cover",
                  borderRadius: "1rem",
                }}
              />
            </Box>
          </Grid>
          <Grid item lg={6}>
            <Box sx={style.aboutBox}>
              <Typography
                sx={style.aboutHeading}
                data-aos="fade-up"
                data-aos-delay="700"
              >
                WELCOME TO ANTIQUE REVIEW SYSTEM
              </Typography>
              <Typography
                data-aos="fade-up"
                data-aos-delay="900"
                sx={{
                  fontFamily: "Poppins",
                  textAlign: "left",
                  paddingY: "16px",
                }}
              >
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. U
                enim ad minim veniam, quis nostrud exercitation ullamco laboris
                nisi ut aliquip ex ea commodo consequat. Duis aute irure dol in
                reprehenderit in
              </Typography>
              <Typography
                data-aos="fade-up"
                data-aos-delay="1000"
                sx={{ fontFamily: "Poppins", textAlign: "left" }}
              >
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. U
                enim ad minim veniam, quis nostrud exercitation ullamco laboris
                nisi ut aliquip ex ea commodo consequat. Duis aute irure dol in
                reprehenderit in
              </Typography>
              <Button
                data-aos="fade-up"
                data-aos-delay="1200"
                variant="outlined"
                sx={style.btn}
              >
                READ MORE
              </Button>
            </Box>
          </Grid>
        </Grid>
        <TeamMembers />
      </Container>
      <Company />
    </Layout>
  );
};
const style = {
  container: {
    maxWidth: { lg: "1450px" },
    paddingY: "3rem",
  },
  strip: {
    background: "#413E43",
  },
  stripText: {
    color: "white",
    fontFamily: "Poppins",
    fontSize: "30px",
    fontWeight: 600,
    letterSpacing: "2px",
    textAlign: "left",
  },
  aboutBox: {
    padding: "20px",
    display: "flex",
    flexDirection: "column",
    alignItems: "start",
    justifyContent: "center",
  },
  aboutHeading: {
    fontFamily: "Poppins",
    fontSize: "28px",
    fontWeight: 700,
    textAlign: "left",
  },
  btn: {
    marginTop: "20px",
    paddingX: "20px",
    fontWeight: 600,
    fontFamily: "Poppins",
    fontSize: "17px",
    border: "1px solid black",
    borderRadius: "5px",
    transition: "all ease-out 0.5s",
    color: "black",
    opacity: 0.8,
    // backgroundColor: "white",
    boxShadow: 1,
    ":hover": {
      backgroundColor: "black",
      border: "1px solid black",
      color: "white",
    },
  },
};
