import React, { useContext, useEffect, useState } from "react";
import { NavBar } from "../../Components/Layout/Navbar/NavBar";
import Hero from "../../Components/Home/Hero";
import CategorySlider from "../../Components/Home/CategorySlider";
import SubCategoryCard from "../../Components/Common/SubCategoryCard";
import { Box, Container, Grid, Typography } from "@mui/material";
import pic from "../../Assets/ProductIImages/11.webp";
import pic1 from "../../Assets/ProductIImages/12.webp";
import pic2 from "../../Assets/ProductIImages/13.webp";
import LatestBlog from "../../Components/Home/LatestBlog";
import { Company } from "../../Components/Home/Company";
import Layout from "../../Components/Layout/Layout";
import { MyContext } from "../../Context/userContext";
import VideoLoader from "../../Components/Home/VideoLoader";
import { NavHome } from "../../Components/Layout/Navbar/NavHome";
import { Footer } from "../../Components/Layout/Footer/Footer";
import { useSelector } from "react-redux";
import { getApprovePosts } from "../../Components/Services/PostServices";

const Index = () => {
  const creative = "#FAC959";
  const scrapyard = "#DDDDDD";
  const heritage = "#F2D7D9";
  const { value } = useContext(MyContext);

  const [showVideo, setShowVideo] = useState(true);

  const [creativePosts, setCreativePosts] = useState([]);
  const [heritagePosts, setHeritagePosts] = useState([]);
  const [scrapyardPosts, setScrapyardPosts] = useState([]);
  const [allPosts, setAllPosts] = useState([]);

  const getAllPosts = () => {
    getApprovePosts()
      .then((data) => {
        setCreativePosts(data.creativePosts);
        setHeritagePosts(data.heritagePosts);
        setScrapyardPosts(data.scrapyardPosts);
        setAllPosts(data.temp);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    getAllPosts();
    const timeout = setTimeout(() => {
      setShowVideo(false);
    }, 5000); // Adjust the duration as needed

    return () => clearTimeout(timeout);
  }, []);

  return (
    <>
      {showVideo ? (
        <VideoLoader />
      ) : (
        <>
          <NavHome />
          <Hero />
          <Box sx={style.catBox}>
            <Container sx={{ maxWidth: { lg: "1450px" } }}>
              <Typography sx={style.heading} data-aos="fade-up">
                Trending Categories
              </Typography>
              <Grid
                container
                spacing={3}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Grid
                  item
                  md={4}
                  sm={6}
                  xs={12}
                  data-aos="fade-up"
                  data-aos-duration="300"
                >
                  <SubCategoryCard src={pic} head={"Art Therapy"} />
                </Grid>
                <Grid
                  item
                  md={4}
                  sm={6}
                  xs={12}
                  data-aos="fade-up"
                  data-aos-duration="600"
                >
                  <SubCategoryCard src={pic1} head={"Photography"} />
                </Grid>
                <Grid
                  item
                  md={4}
                  sm={6}
                  xs={12}
                  data-aos="fade-up"
                  data-aos-duration="900"
                >
                  <SubCategoryCard src={pic2} head={"Digital Illustration"} />
                </Grid>
              </Grid>
            </Container>
          </Box>

          <Box
            sx={{
              backgroundColor: value === "CREATIVE" && creative,
            }}
          >
            <CategorySlider
              heading={"Explore Our Creatives"}
              items={creativePosts}
            />
          </Box>
          <Box
            sx={{
              backgroundColor: value === "HERITAGE" && heritage,
            }}
          >
            <CategorySlider
              heading={"Explore Our Culture Heritage"}
              items={heritagePosts}
            />
          </Box>
          <Box
            sx={{
              backgroundColor: value === "SCRAPYARD" && scrapyard,
            }}
          >
            <CategorySlider
              heading={"Explore Our Scrapyard"}
              items={scrapyardPosts}
            />
          </Box>
          <CategorySlider heading={"Featured Products"} items={allPosts} />
          <Company />
          <LatestBlog />
          <Footer />
        </>
      )}
    </>
  );
};

export default Index;
const style = {
  catBox: {
    paddingY: "3rem",
  },
  heading: {
    fontSize: { sm: "40px", xs: "28px" },
    fontFamily: "Poppins",
    paddingY: "2rem",
    fontWeight: 700,
  },
};
