import React, { useEffect, useState } from "react";
import Layout from "../../Components/Layout/Layout";
import Stripe from "../../Components/Common/Stripe";
import {
  Box,
  Button,
  Container,
  Grid,
  Pagination,
  Typography,
} from "@mui/material";
import { useParams } from "react-router-dom";
import { useLocation } from "react-router-dom";
import x1 from "../../Assets/ProductIImages/x1.avif";
import x2 from "../../Assets/ProductIImages/x2.avif";
import x3 from "../../Assets/ProductIImages/x3.avif";
import x4 from "../../Assets/ProductIImages/x4.avif";
import x5 from "../../Assets/ProductIImages/x5.avif";
import x6 from "../../Assets/ProductIImages/x6.avif";
import ProductCard from "../../Components/Common/ProductCard";
import { IoFilterSharp } from "react-icons/io5";
import { getApprovePosts } from "../../Components/Services/PostServices";
import toast from "react-hot-toast";

const Scrapy = [
  "Scrap Metal Recycling",
  "Junkyard Finds",
  "Vehicle Salvage",
  "Metal Scrapping",
  "Recycled Auto Parts",
  "Industrial Waste Management",
  "E-Waste Disposal",
  "Scrap Electronics Recycling",
  "Steel Scrap Processing",
  "Waste Material Recovery",
];
const creativ = [
  "Visual Arts",
  "Craft Making",
  "Graphic Design",
  "Digital Illustration",
  "Photography",
  "Creative Writing",
  "Music Composition",
  "Film Production",
  "Performing Arts",
  "Art Therapy",
];
const heritageC = ["Sindhi", "Islamabadi", "Quettawal", "Balochi", "Marwati"];

const Category = () => {
  const location = useLocation();
  const creative = "linear-gradient(to top, #BCBEC0 , #FFFFFF)";
  const scrapyard = "linear-gradient(to top, #BCBEC0 , #FFFFFF)";
  const heritage = "linear-gradient(to top, #BCBEC0 , #FFFFFF)";
  const [mainCategory, setMainCategory] = useState("ALL CATEGORY");
  const [subCat, setSubCat] = useState([]);
  const [selectedSubCategory, setSelectedSubCategory] = useState("");
  const [CurrentList, setCurrentList] = useState([]);
  const [creativePosts, setCreativePosts] = useState([]);
  const [heritagePosts, setHeritagePosts] = useState([]);
  const [scrapyardPosts, setScrapyardPosts] = useState([]);
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");

  const getAllPosts = () => {
    getApprovePosts()
      .then((data) => {
        setCreativePosts(data.creativePosts);
        setHeritagePosts(data.heritagePosts);
        setScrapyardPosts(data.scrapyardPosts);
        if (mainCategory === "heritage") {
          setSubCat(heritageC);
          setCurrentList(data.heritagePosts);
        } else if (mainCategory === "scrapyard") {
          setSubCat(Scrapy);
          setCurrentList(data.scrapyardPosts);
        } else {
          setSubCat(creativ);
          setCurrentList(data.creativePosts);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const handleSubCat = (name) => {
    setSelectedSubCategory(name);
  };

  const handleFilter = () => {
    if (!CurrentList || !CurrentList.length) {
      console.error("Current list is empty or unavailable.");
      return;
    }

    if (!minPrice || !maxPrice) {
      console.error("Please enter both minimum and maximum prices.");
      return;
    }

    const filtered = CurrentList.filter((product) => {
      const price = Number(product.item.post.price); // Assuming 'price' is the field containing the product price
      return price >= minPrice && price <= maxPrice;
    });

    setCurrentList(filtered);
  };
  useEffect(() => {
    getAllPosts();
  }, [mainCategory]);
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const categoryParam = searchParams.get("category");
    const subcategoryParam = searchParams.get("subCategory");
    console.log(subcategoryParam, "subcategoryParam");
    if (categoryParam) {
      setMainCategory(categoryParam);
    }
    if (subcategoryParam) {
      console.log(subcategoryParam, "subcategoryParam");
      setSelectedSubCategory(subcategoryParam);
    }
  }, [location.search]);

  useEffect(() => {
    if (CurrentList && mainCategory === "heritage") {
      setCurrentList(
        heritagePosts.filter(
          (data) => data.item.post.subCategory === selectedSubCategory
        )
      );
    } else if (CurrentList && mainCategory === "scrapyard") {
      setCurrentList(
        scrapyardPosts.filter(
          (data) => data.item.post.subCategory === selectedSubCategory
        )
      );
    } else if (CurrentList && mainCategory === "creative") {
      setCurrentList(
        creativePosts.filter(
          (data) => data.item.post.subCategory === selectedSubCategory
        )
      );
    } else {
    }
  }, [selectedSubCategory]);

  return (
    <Layout>
      <Box
        sx={{
          paddingY: "1rem",
          background:
            mainCategory === "heritage"
              ? heritage
              : mainCategory === "scrapyard"
              ? scrapyard
              : mainCategory === "creative"
              ? creative
              : "white",
        }}
      >
        <Box>
          <Container sx={{ maxWidth: { lg: "1400px" } }}>
            <Box
              sx={{
                display: "flex",

                justifyContent: "center",
                gap: "10px",
                paddingY: "1rem",
                flexWrap: "wrap",
              }}
            >
              {subCat?.map((data, index) => {
                return (
                  <React.Fragment key={index}>
                    <Typography
                      sx={
                        selectedSubCategory === data
                          ? style.activeSub
                          : style.sub1
                      }
                      onClick={() => {
                        handleSubCat(data);
                      }}
                    >
                      {data}
                    </Typography>
                  </React.Fragment>
                );
              })}
            </Box>
            <Grid
              container
              sx={{ border: "1px solid grey", borderRadius: "10px" }}
            >
              <Grid
                item
                lg={3}
                sx={{
                  borderRight: "1px solid grey",
                  padding: "15px",
                  display: { lg: "block", xs: "none" },
                }}
              >
                <Box sx={style.filterBox}>
                  <Typography sx={style.filterHeadings}>
                    By Categories
                  </Typography>
                  <Box sx={style.categoryBox}>
                    {subCat?.map((data, index) => {
                      return (
                        <React.Fragment key={index}>
                          <Typography
                            onClick={() => {
                              handleSubCat(data);
                            }}
                            sx={
                              selectedSubCategory === data
                                ? style.activeSub
                                : style.sub1
                            }
                          >
                            {data}
                          </Typography>
                        </React.Fragment>
                      );
                    })}
                  </Box>
                  <hr />
                  <Typography sx={style.filterHeadings}>Price Range</Typography>
                  <Box sx={style.priceRangeBox}>
                    <input
                      className="input-grey-rounded-price"
                      type="number"
                      placeholder="MIN"
                      value={minPrice}
                      onChange={(e) => setMinPrice(e.target.value)}
                    />
                    <input
                      className="input-grey-rounded-price"
                      type="number"
                      placeholder="MAX"
                      value={maxPrice}
                      onChange={(e) => setMaxPrice(e.target.value)}
                    />
                  </Box>
                  <hr />
                  {/* <Typography sx={style.filterHeadings}>Size</Typography>
                  <Box sx={style.priceRangeBox}>
                    <Box sx={style.sizeBox}>
                      <Typography sx={style.size}>S</Typography>
                    </Box>
                    <Box sx={style.sizeBox}>
                      <Typography sx={style.size}>M</Typography>
                    </Box>
                    <Box sx={style.sizeBox}>
                      <Typography sx={style.size}>L</Typography>
                    </Box>
                    <Box sx={style.sizeBox}>
                      <Typography sx={style.size}>XL</Typography>
                    </Box>
                  </Box> */}
                  <Button
                    variant="outlined"
                    sx={[style.btn, { marginTop: "0px" }]}
                    onClick={handleFilter}
                  >
                    FILTER
                  </Button>
                </Box>
              </Grid>
              <Grid
                item
                lg={9}
                xs={12}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  flexDirection: "column",
                  paddingX: "10px",
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    flexDirection: "row",
                    justifyContent: { lg: "end", xs: "space-between" },
                    width: "100%",
                  }}
                >
                  <Box sx={{ display: { lg: "none", xs: "block" } }}>
                    <IoFilterSharp
                      style={{ marginTop: "14px", fontSize: 22 }}
                    />
                  </Box>
                  <Typography sx={style.showin}>
                    Showing {CurrentList?.length} Results
                  </Typography>
                </Box>

                {CurrentList && CurrentList.length > 0 ? (
                  <Grid container spacing={2}>
                    {CurrentList.map((data) => {
                      return (
                        <Grid item md={4} sm={6} xs={12}>
                          <ProductCard src={data} />
                        </Grid>
                      );
                    })}
                  </Grid>
                ) : (
                  <Typography>No Data Avialable At The Moment</Typography>
                )}
                {/* <Pagination
                  count={5}
                  sx={{ marginY: "1rem", fontSize: "22px" }}
                /> */}
              </Grid>
            </Grid>
          </Container>
        </Box>
      </Box>
    </Layout>
  );
};

export default Category;
const style = {
  sizeBox: {
    borderRadius: "2px",
    paddingX: "12px",
    paddingY: "4px",
    border: "1px solid black",
    color: "black",
    transition: "all ease-out 0.5s",
    ":hover": {
      background: "black",
      color: "white",
    },
  },
  filterBox: {
    width: "100%",
    padding: "10px",
    display: "flex",
    flexDirection: "column",
    alignItems: "start",
    justifyContent: "start",
  },
  filterHeadings: {
    color: "black",
    opacity: 0.7,
    fontSize: "22px",
    fontFamily: "Poppins",
    paddingBottom: "14px",
    textTransform: "uppercase",
    fontWeight: 600,
  },
  ProductBox: {
    width: "100%",
  },
  priceRangeBox: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "start",
    gap: "12px",
  },
  size: {
    fontFamily: "Poppins",
    fontWeight: 600,
  },
  btn: {
    marginTop: "14px",
    paddingX: "20px",
    fontWeight: 600,
    fontFamily: "Poppins",
    fontSize: "16px",
    border: "1px solid black",
    borderRadius: "5px",
    transition: "all ease-out 0.5s",
    color: "black",
    opacity: 0.8,
    // backgroundColor: "white",
    boxShadow: 1,
    ":hover": {
      backgroundColor: "black",
      border: "1px solid black",
      color: "white",
    },
  },
  categoryBox: {
    paddingY: "10px",
    display: "flex",
    flexDirection: "column",
    alignItems: "start",
    justifyContent: "start",
    gap: "8px",
  },
  sub: {
    fontFamily: "Poppins",
    transition: "all ease-out 0.2s",
    cursor: "pointer",
    ":hover": {
      fontWeight: 600,
    },
  },
  sub1: {
    fontFamily: "Poppins",
    transition: "all ease-out 0.2s",
    cursor: "pointer",
    border: "1px solid transparent",
    padding: "5px",
    borderRadius: "5px",
    ":hover": {
      border: "1px solid grey",
      color: "white",
      backgroundColor: "black",
    },
  },
  activeSub: {
    fontFamily: "Poppins",
    transition: "all ease-out 0.2s",
    cursor: "pointer",
    padding: "5px",
    borderRadius: "5px",
    border: "1px solid grey",
    color: "white",
    backgroundColor: "black",
  },
  showin: {
    textAlign: "right",
    fontFamily: "Poppins",
    paddingTop: "20px",
    width: "100%",
  },
};
