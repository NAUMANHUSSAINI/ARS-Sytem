import React from "react";
import Layout from "../../Components/Layout/Layout";
import {
  Box,
  Button,
  ButtonGroup,
  Container,
  Grid,
  Typography,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import dryer from "../../Assets/ProductIImages/dryer.webp";
import r from "../../Assets/ProductIImages/r.png";
import { useDispatch, useSelector } from "react-redux";
import {
  calculateTotal,
  clearCart,
  removeFromCart,
  updateCart,
} from "../../Redux/Cart/CartSlice";
import axios from "axios";
import { createOrder } from "../../Components/Services/PostServices";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";

const Cart = () => {
  const dispatch = useDispatch();

  const cart = useSelector((state) => state.cart.cart);
  const total = useSelector((state) => state.cart.total);
  const user = useSelector((state) => state.user.user);
  const checkout = async () => {
    let temp = {
      cart,
      total,
      customerId: user?.id,
    };
    if (cart.length > 0) {
      try {
        // Call your backend to create a Checkout Session
        const { data } = await axios.post(
          "http://localhost:3000/create-checkout-session",
          { amount: total }
        ); // Example amount in cents
        // Redirect to Stripe Checkout
        window.location.href = data.url;
      } catch (error) {
        console.error("Error redirecting to checkout:", error);
        // Handle error
      }
      // createOrder(temp).then((data) => {
      //   if (data.success == true) {
      //     toast.success("Order Placed Successfully");
      //     navigate(`/user/success?id=${data.orderId}`);
      //   } else {
      //     toast.error("Order Not Placed Successfully");
      //   }
      // });
    }
  };
  console.log(user, "user");

  return (
    <Layout>
      <Container sx={style.container}>
        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Typography sx={style.mainHeading}>Shopping Cart</Typography>
          <Typography
            onClick={() => {
              dispatch(clearCart());
              dispatch(calculateTotal());
            }}
            sx={{
              width: "200px",
              padding: "5px",
              borderRadius: "10px",
              border: "1px solid grey",
              fontFamily: "Poppins",
            }}
          >
            Delete All Items
          </Typography>
        </Box>
        <Grid container spacing={3}>
          <Grid item lg={6} xs={12}>
            {cart.length > 0 ? (
              cart?.map((data, index) => {
                return (
                  <>
                    <Box sx={style.itemsDetaislBox} key={index}>
                      <img
                        src={data?.item?.imageUrls[0]}
                        alt="oops"
                        style={{ width: "200px", height: "200px" }}
                      />
                      <Box sx={style.commondetails}>
                        <Typography sx={style.productName}>
                          {data?.item?.post?.title}
                        </Typography>
                        <Typography sx={style.productType}>
                          {" "}
                          {data?.item?.post?.subCategory}
                        </Typography>
                        <Typography sx={style.productPrice}>
                          RS. {data?.item?.post?.price}
                        </Typography>
                        <Typography sx={style.productPrice}>
                          <ButtonGroup
                            color="secondary"
                            aria-label="Medium-sized button group"
                          >
                            <Button
                              onClick={() => {
                                dispatch(
                                  updateCart({
                                    id: data.id,
                                    quantity: data?.quantity - 1,
                                  })
                                );
                                dispatch(calculateTotal());
                              }}
                            >
                              -
                            </Button>
                            <Button disabled>{data?.quantity}</Button>
                            <Button
                              onClick={() => {
                                dispatch(
                                  updateCart({
                                    id: data.id,
                                    quantity: data?.quantity + 1,
                                  })
                                );
                                dispatch(calculateTotal());
                              }}
                            >
                              +
                            </Button>
                          </ButtonGroup>
                        </Typography>
                      </Box>
                      <Box sx={style.removeBox}>
                        <Button
                          onClick={() => {
                            let id = data.id;
                            dispatch(removeFromCart({ id }));
                            dispatch(calculateTotal());
                          }}
                          sx={{ fontFamily: "Poppins", color: "black" }}
                        >
                          <DeleteIcon /> Remove
                        </Button>
                      </Box>
                    </Box>
                  </>
                );
              })
            ) : (
              <Typography sx={[style.productPrice, { width: "100%" }]}>
                No Items In The Cart
              </Typography>
            )}
          </Grid>
          <Grid item lg={6} xs={12}>
            <Box
              sx={[
                style.itemsDetaislBox,
                { flexDirection: "column !important", width: "100%" },
              ]}
            >
              <Typography sx={[style.productPrice, { width: "100%" }]}>
                Order Summary{" "}
              </Typography>
              <Box
                sx={{
                  width: "100%",
                  background: "grey",
                  height: "1px",
                }}
              ></Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "space-between",
                  width: "100%",
                }}
              >
                <Typography sx={[style.productName, { width: "100%" }]}>
                  Items({cart.length}) Subtotal
                </Typography>
                <Typography sx={[style.productPrice, { width: "150px" }]}>
                  RS. {total}
                </Typography>
              </Box>
              <Typography sx={[style.productPrice, { width: "100%" }]}>
                Dilevery Fees not included
              </Typography>
              <Button sx={style.btnCheckout} onClick={checkout}>
                Go To Checkout (STRIPE)
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Container>
    </Layout>
  );
};

export default Cart;
const style = {
  container: {
    maxWidth: { lg: "1350px" },
    marginY: "3rem",
  },
  itemsDetaislBox: {
    background: "white",
    border: "1px solid grey",
    padding: { xl: "2rem", lg: "1rem", xs: "0.5rem" },
    position: "relative",
    boxShadow: 5,
    display: "flex",
    flexDirection: { sm: "row", xs: "column" },
    alignItems: "center",
    justifyContent: "start",
    gap: "20px",
  },
  commondetails: {},
  productName: {
    fontFamily: "Poppins",
    color: "black",
    opacity: 0.7,
    fontWeight: 600,
    marginBottom: "14px",
    fontSize: 20,
    textTransform: "capitalize",
    textAlign: "left",
  },
  productType: {
    fontFamily: "Poppins",
    fontWeight: 600,
    fontSize: 18,
    color: "black",
    opacity: 0.5,
    marginBottom: "10px",
    textAlign: "left",
  },
  productPrice: {
    fontFamily: "Poppins",
    fontWeight: 600,
    fontSize: 22,
    color: "black",
    marginBottom: "10px",
    textAlign: "left",
  },
  removeBox: {
    position: "absolute",
    bottom: 20,
    right: 20,
  },
  mainHeading: {
    fontFamily: "Poppins",
    fontWeight: 700,
    width: "100%",
    color: "black",
    paddingY: "20px",
    fontSize: 35,
    textAlign: "left",
  },
  btnCheckout: {
    fontFamily: "Poppins",
    fontWeight: 600,
    color: "white",
    marginY: "15px",
    border: "1px solid grey",
    background: "black",
    transition: "all ease-out 0.5s",
    width: "100%",
    paddingY: "8px",
    fontSize: 18,
    ":hover": {
      background: "white",
      color: "grey",
    },
  },
};
