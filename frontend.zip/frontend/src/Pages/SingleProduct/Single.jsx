import React, { useEffect, useState } from "react";
import Layout from "../../Components/Layout/Layout";
import { useLocation } from "react-router-dom";
import { Box, Button, Chip, Container, Grid, Typography } from "@mui/material";
import imag from "../../Assets/ProductIImages/12.webp";
import imag1 from "../../Assets/ProductIImages/13.webp";
import { getProductByID } from "../../Components/Services/PostServices";
import toast from "react-hot-toast";
import { useDispatch, useSelector } from "react-redux";
import { addToCart, calculateTotal } from "../../Redux/Cart/CartSlice";

const Single = () => {
  const location = useLocation();
  const dispatch = useDispatch();
  const [product, setProduct] = useState();
  const cart = useSelector((state) => state.cart.cart);
  const [CurrentImage, setCurrentImage] = useState(product?.item?.imageUrls[0]);
  const getProduct = (id) => {
    getProductByID(id).then((data) => {
      if (data) {
        setProduct(data);
        console.log(data, "product");
      } else {
        toast.error("cannot find product");
      }
    });
  };
  const addItemToRedux = () => {
    console.log(product, "dispatch");
    dispatch(addToCart(product));
    dispatch(calculateTotal());
  };
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const ID = searchParams.get("ID");
    if (ID) {
      getProduct(ID);
    }
  }, [location.search]);
  useEffect(() => {
    dispatch(calculateTotal());
  }, [cart, dispatch]);
  return (
    <Layout>
      <Box sx={{ paddingY: "3rem" }}>
        <Container sx={{ maxWidth: { lg: "1450px" } }}>
          <Grid container spacing={3}>
            <Grid item lg={6} xs={12}>
              <Box sx={style.imageplusCarousel}>
                <Box>
                  <img
                    src={
                      CurrentImage
                        ? CurrentImage
                        : product && product?.item?.imageUrls[0]
                    }
                    alt="oops"
                    style={{ width: "360px", height: "auto" }}
                  />
                </Box>

                <Box sx={style.carouselBox}>
                  {product &&
                    product?.item?.imageUrls.length > 0 &&
                    product?.item?.imageUrls?.map((src, index) => {
                      return (
                        <>
                          <img
                            src={src}
                            alt="oops"
                            style={{ width: "100px", height: "auto" }}
                            key={index}
                            onClick={() => {
                              setCurrentImage(src);
                            }}
                          />
                        </>
                      );
                    })}
                </Box>
              </Box>
            </Grid>
            <Grid item lg={6} xs={12}>
              <Box sx={style.contentBox}>
                <Typography sx={style.heading}>
                  {product?.item?.post?.title}
                </Typography>
                <Typography sx={style.price}>
                  RS. {product?.item?.post?.price}
                </Typography>
                <Typography sx={style.descHead}>Description</Typography>
                <Typography sx={style.desc}>
                  {product?.item?.post?.desc}
                </Typography>
                {/* <Typography sx={style.descHead}>Select Size</Typography> */}
                {/* <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center",
                    gap: "12px",
                    marginBottom: "10px",
                  }}
                >
                  <Box sx={style.size}>S</Box>
                  <Box sx={style.size}>M</Box>
                  <Box sx={style.size}>L</Box>
                  <Box sx={style.size}>XL</Box>
                </Box> */}
                {/* <Typography sx={style.descHead}>Select Color</Typography>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center",
                    gap: "12px",
                    marginBottom: "10px",
                  }}
                >
                  <Box sx={[style.color, { background: "grey" }]}> </Box>
                  <Box sx={[style.color, { background: "red" }]}> </Box>
                  <Box sx={[style.color, { background: "green" }]}> </Box>
                  <Box sx={[style.color, { background: "purple" }]}> </Box>
                </Box> */}
                <Button sx={style.btn} onClick={() => addItemToRedux()}>
                  ADD TO CART
                </Button>
                {/* <Typography sx={style.descHead}>Tags</Typography> */}
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center",
                    gap: "12px",
                    marginBottom: "10px",
                  }}
                >
                  <Chip label={product?.item?.post?.category} />
                  <Chip label={product?.item?.post?.subCategory} />
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </Layout>
  );
};

export default Single;
const style = {
  imageplusCarousel: {
    width: "100%",
    padding: "1rem",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: "1rem",
  },
  carouselBox: {
    width: { md: "60%", xs: "95%" },
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: "14px",
    overflowX: "scroll",
    padding: "10px",
    "&::-webkit-scrollbar": {
      width: "0px",
      height: "6px",
    },
    "&::-webkit-scrollbar-thumb": {
      backgroundColor: "grey",
      borderRadius: "20px",
    },
    "&::-webkit-scrollbar-thumb:hover": {
      backgroundColor: "grey",
    },
  },
  contentBox: {
    width: "100%",
    padding: "1rem",
    display: "flex",
    flexDirection: "column",
    alignItems: "start",
    justifyContent: "start",
    gap: "0.7rem",
  },
  heading: {
    fontFamily: "Poppins",
    fontSize: "35px",
    fontWeight: 700,
    color: "black",
    opacity: 0.8,
    textAlign: "left",
  },
  price: {
    fontFamily: "Poppins",
    fontSize: "24px",
    fontWeight: 600,
    color: "black",
    opacity: 0.7,
  },
  descHead: {
    display: "block",
    fontSize: "18px",
    lineHeight: "12px",
    // marginBottom: "15px",
    paddingBottom: "10px",
    position: "relative",
    fontFamily: "Poppins",
    fontWeight: 600,
    "::before": {
      backgroundColor: "#3f51b5",
      bottom: 0,
      content: '""',
      height: "1px",
      left: 0,
      position: "absolute",
      width: "30px",
    },
  },
  desc: {
    fontFamily: "Poppins",
    textAlign: "left",
    marginBottom: "10px",
  },
  size: {
    padding: " 6px 12px",
    borderRadius: "2px",
    background: "#EFEFEF",
    fontFamily: "Poppins",
    fontWeight: 700,
    transition: "all ease-out 0.5s",
    ":hover": {
      backgroundColor: "black",
      color: "white",
    },
  },
  color: {
    width: "50px",
    height: "50px",
    borderRadius: "4px",
  },
  btn: {
    boxShadow: 2,
    fontFamily: "Poppins",
    marginY: "10px",
    fontWeight: 600,
    border: "1px solid black",
    transition: "all ease-out 0.5s",
    color: "black",
    paddingX: "3rem",
    ":hover": {
      backgroundColor: "black",
      color: "white",
    },
  },
};
