import * as React from "react";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import {
  deletePost,
  getPostById,
} from "../../Components/Services/PostServices";
import { useSelector } from "react-redux";
import {
  Avatar,
  Box,
  Button,
  Chip,
  CircularProgress,
  Container,
  Typography,
} from "@mui/material";
import DashboardLayout from "../../Components/Layout/DashboardLayout";
import { BiSolidEdit } from "react-icons/bi";
import { MdDelete } from "react-icons/md";
import toast from "react-hot-toast";
const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
    fontFamily: "Poppins",
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
    fontFamily: "Poppins",
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const UserAdsListing = () => {
  const [rows, setRow] = React.useState([]);

  const user = useSelector((state) => state.user.user);

  const getPosts = () => {
    getPostById(user.id).then((data) => {
      setRow(data);
    });
  };
  const deleteAds = (id) => {
    deletePost(id)
      .then(() => {
        toast.success("Ad Deleted Successfully");
        getPosts();
      })
      .catch((err) => {
        toast.error("Ad not Deleted Successfully");
      });
  };

  React.useEffect(() => {
    getPosts();
  }, []);
  return (
    <DashboardLayout>
      <Box sx={{ marginTop: "60px", width: "100%" }}>
        <Container sx={{ maxWidth: { lg: "1400px" } }}>
          {rows && rows?.length > 0 ? (
            <TableContainer component={Paper}>
              <Table sx={{ width: "100%" }} aria-label="customized table">
                <TableHead>
                  <TableRow>
                    <StyledTableCell>Image</StyledTableCell>
                    <StyledTableCell>Title</StyledTableCell>
                    <StyledTableCell>Price</StyledTableCell>
                    <StyledTableCell>Status</StyledTableCell>
                    <StyledTableCell>Action</StyledTableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row) => (
                    <StyledTableRow key={row.id}>
                      <StyledTableCell component="th" scope="row">
                        <Avatar
                          alt={row.item.post.title}
                          src={row.item.imageUrls[0]}
                          sx={{ width: 56, height: 56 }}
                        />
                      </StyledTableCell>
                      <StyledTableCell>
                        <Typography
                          sx={{ fontFamily: "Poppins", fontWeight: 600 }}
                        >
                          {row.item.post.title}
                        </Typography>{" "}
                      </StyledTableCell>
                      <StyledTableCell>
                        <Typography
                          sx={{ fontFamily: "Poppins", fontWeight: 600 }}
                        >
                          Rs .{row.item.post.price}{" "}
                        </Typography>
                      </StyledTableCell>
                      <StyledTableCell>
                        {" "}
                        <Chip
                          label={row.item.post.status}
                          color={
                            row.item.post.status == "pending"
                              ? "warning"
                              : row.item.post.status == "approve"
                              ? "success"
                              : "error"
                          }
                        />
                      </StyledTableCell>
                      <StyledTableCell>
                        <Box
                          sx={{
                            display: "flex",
                            flexDirection: "row",
                            alignItems: "center",
                            gap: "12px",
                          }}
                        ></Box>
                        {/* <Button
                          variant="contained"
                          sx={[style.btn, { marginRight: "10px" }]}
                        >
                          <BiSolidEdit style={{ fontSize: 20 }} />
                        </Button> */}
                        <Button
                          onClick={() => deleteAds(row.id)}
                          variant="contained"
                          sx={[style.btn, { ":hover": { background: "red" } }]}
                        >
                          <MdDelete style={{ fontSize: 20 }} />
                        </Button>
                      </StyledTableCell>
                    </StyledTableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          ) : (
            <Box
              sx={{
                height: "100vh",
                width: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <h1>You Have No Products Listed.</h1>
            </Box>
          )}
        </Container>
      </Box>
    </DashboardLayout>
  );
};

export default UserAdsListing;
const style = {
  btn: {
    fontWeight: 600,
    fontFamily: "Poppins",
    border: "1px solid black",
    borderRadius: "5px",
    transition: "all ease-out 0.5s",
    color: "black",
    opacity: 0.8,
    // display: { md: "block", xs: "none" },
    backgroundColor: "white",
    boxShadow: 1,
    ":hover": {
      backgroundColor: "black",
      border: "1px solid black",
      color: "white",
    },
  },
};
