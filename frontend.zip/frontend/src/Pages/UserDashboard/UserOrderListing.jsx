import React, { useEffect } from "react";
import DashboardLayout from "../../Components/Layout/DashboardLayout";
import { Box, Chip, Container, Typography } from "@mui/material";
import { getUserOrders } from "../../Components/Services/PostServices";
import { useSelector } from "react-redux";
import { BiSolidEdit } from "react-icons/bi";
import { MdDelete } from "react-icons/md";
import toast from "react-hot-toast";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
    fontFamily: "Poppins",
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
    fontFamily: "Poppins",
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));
const UserOrderListing = () => {
  const user = useSelector((state) => state.user.user);
  const [rows, setRow] = React.useState([]);
  const getOrder = () => {
    getUserOrders(user.id).then((data) => {
      if (data) {
        setRow(data);
      }
    });
  };
  useEffect(() => {
    getOrder();
  }, []);
  return (
    <>
      <DashboardLayout>
        <Box sx={{ marginTop: "60px", width: "100%" }}>
          <Container sx={{ maxWidth: { lg: "1400px" } }}>
            {rows && rows?.length > 0 ? (
              <TableContainer component={Paper}>
                <Table sx={{ width: "100%" }} aria-label="customized table">
                  <TableHead>
                    <TableRow>
                      <StyledTableCell>Order ID</StyledTableCell>
                      <StyledTableCell>Amount</StyledTableCell>
                      <StyledTableCell>Items</StyledTableCell>
                      <StyledTableCell>Total Quantity</StyledTableCell>
                      <StyledTableCell>Status</StyledTableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {rows.map((row) => {
                      const totalQuantity = row?.items.reduce(
                        (sum, item) => sum + item.quantity,
                        0
                      );
                      return (
                        <StyledTableRow key={row.id}>
                          <StyledTableCell component="th" scope="row">
                            <Typography
                              sx={{ fontFamily: "Poppins", fontWeight: 600 }}
                            >
                              Order #{row?.orderId}
                            </Typography>{" "}
                          </StyledTableCell>
                          <StyledTableCell>
                            <Typography
                              sx={{ fontFamily: "Poppins", fontWeight: 600 }}
                            >
                              PKR {row?.total}
                            </Typography>{" "}
                          </StyledTableCell>
                          <StyledTableCell>
                            <Typography
                              sx={{ fontFamily: "Poppins", fontWeight: 600 }}
                            >
                              {row?.items?.length}
                            </Typography>
                          </StyledTableCell>
                          <StyledTableCell>
                            {" "}
                            {/* <Chip
                          label={row.item.post.status}
                          color={
                            row.item.post.status == "pending"
                              ? "warning"
                              : row.item.post.status == "approve"
                              ? "success"
                              : "error"
                          }
                        /> */}
                            <Typography
                              sx={{ fontFamily: "Poppins", fontWeight: 600 }}
                            >
                              {totalQuantity}
                            </Typography>
                          </StyledTableCell>
                          <StyledTableCell>
                            <Chip
                              label={row?.shippingStatus}
                              color={
                                row?.shippingStatuss == "placed"
                                  ? "warning"
                                  : row?.shippingStatuss == "shipping"
                                  ? "success"
                                  : "error"
                              }
                            />
                          </StyledTableCell>
                        </StyledTableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            ) : (
              <Box
                sx={{
                  height: "100vh",
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <h1>You Have No Orders Yet.</h1>
              </Box>
            )}
          </Container>
        </Box>
      </DashboardLayout>
    </>
  );
};

export default UserOrderListing;
const style = {
  btn: {
    fontWeight: 600,
    fontFamily: "Poppins",
    border: "1px solid black",
    borderRadius: "5px",
    transition: "all ease-out 0.5s",
    color: "black",
    opacity: 0.8,
    backgroundColor: "white",
    boxShadow: 1,
    ":hover": {
      backgroundColor: "black",
      border: "1px solid black",
      color: "white",
    },
  },
};
