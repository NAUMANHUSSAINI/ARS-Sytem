import React, { useRef, useState } from "react";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
// import { storage } from './firebaseConfig';
import DashboardLayout from "../../Components/Layout/DashboardLayout";
import {
  Box,
  Button,
  Grid,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from "@mui/material";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import { storage } from "../../Config/Config";
import { subcategories } from "../../Constants/Subcategories";
import toast from "react-hot-toast";
import { CreatePost } from "../../Components/Services/PostServices";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
const inital = {
  price: "",
  title: "",
  desc: "",
  city: "",
  zip: "",
  category: "",
  subCategory: "",
  status: "pending",
};
const cities = [
  "Karachi",
  "Lahore",
  "Islamabad",
  "Rawalpindi",
  "Quetta",
  "Peshawar",
  "Faisalabad",
  "Multan",
  "Hyderabad",
  "Sialkot",
  "Gujranwala",
  "Sargodha",
  "Bahawalpur",
  "Sukkur",
  "Larkana",
];

const UserCreatePost = () => {
  const navigate = useNavigate();
  const [alignment, setAlignment] = React.useState("Scrapyard");
  const user = useSelector((state) => state.user.user);
  const inputRef = useRef();
  const [imageUrls, setImageUrls] = useState([]);
  const [post, setPost] = useState(inital);

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
    setPost((prev) => ({
      ...prev,
      category: newAlignment,
      subCategory: "",
    }));
  };
  const postFeildsChange = (val, key) => {
    setPost((prev) => ({
      ...prev,
      [key]: val,
    }));
  };
  const handleSubcategoryChange = (event) => {
    setPost((prev) => ({
      ...prev,
      subCategory: event.target.value,
    }));
  };
  const handleFileChange = async (event) => {
    const files = event.target.files;
    const promises = [];
    const urls = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const storageRef = ref(storage, `images/${file.name}`);
      const uploadTask = uploadBytes(storageRef, file)
        .then(async () => {
          const downloadURL = await getDownloadURL(storageRef);
          urls.push(downloadURL);
        })
        .catch((error) => {
          console.error("Error uploading file:", error);
        });

      promises.push(uploadTask);
    }

    await Promise.all(promises);
    setImageUrls(urls);
  };
  const submit = () => {
    const { price, title, desc, city, zip, category, subCategory } = post;
    if (
      !price ||
      !title ||
      !desc ||
      !city ||
      !zip ||
      !category ||
      !subCategory ||
      imageUrls.length === 0
    ) {
      toast.error("All fields are required.");
      return;
    } else {
      let temp = {
        post,
        imageUrls,
      };
      CreatePost(temp, user.id)
        .then(() => {
          toast.success(
            "Ad is created . Wait untill admin approves it Thankyou"
          );
          setPost(inital);
          setImageUrls([]);
          navigate("/dashboard/user-ads-listings");
        })
        .catch((err) => {
          console.log(err);
          toast.error("Something Went Wrong");
        });
    }
  };
  return (
    <>
      <DashboardLayout>
        <Box
          sx={{
            width: "100%",

            marginTop: "60px",
          }}
        >
          <Typography sx={style.heading}>Publish Your Ads</Typography>
          <Grid container>
            <Grid item lg={6}>
              <Box
                sx={{
                  width: "100%",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "start",
                }}
              >
                <Typography sx={style.heading1}>
                  Upload Product Media :
                </Typography>
                <label className="picture" for="picture__input" tabIndex="0">
                  <span
                    className="picture__image"
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "10px",
                    }}
                  >
                    {" "}
                    <CloudUploadIcon />
                    Upload Image
                  </span>
                </label>

                <input
                  ref={inputRef}
                  type="file"
                  name="picture__input"
                  id="picture__input"
                  accept="image/*"
                  onChange={handleFileChange}
                  multiple
                />
              </Box>
              <Box
                sx={{
                  width: "100%",
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "center",
                  gap: "12px",
                  marginY: "1rem",
                }}
              >
                {imageUrls &&
                  imageUrls.length > 0 &&
                  imageUrls.map((data, index) => {
                    return (
                      <>
                        <img
                          src={data}
                          alt="oops"
                          key={index}
                          style={{
                            width: "150px",
                            height: "150px",
                            objectFit: "cover",
                            borderRadius: "10px",
                          }}
                        />
                      </>
                    );
                  })}
              </Box>
            </Grid>
            <Grid item lg={6}>
              <Box
                sx={{
                  width: "100%",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "start",
                }}
              >
                <Typography sx={style.heading1}>
                  Product Information :
                </Typography>
                <Typography sx={style.label}>Select Category</Typography>
                <ToggleButtonGroup
                  color="secondary"
                  value={alignment}
                  exclusive
                  onChange={handleChange}
                  aria-label="Platform"
                  sx={{ marginBottom: "20px" }}
                >
                  <ToggleButton
                    sx={{ color: "black", fontFamily: "Poppins" }}
                    value="Scrapyard"
                  >
                    Scrapyard
                  </ToggleButton>
                  <ToggleButton
                    sx={{ color: "black", fontFamily: "Poppins" }}
                    value="Culture"
                  >
                    Culture Heritage
                  </ToggleButton>
                  <ToggleButton
                    sx={{ color: "black", fontFamily: "Poppins" }}
                    value="Creative"
                  >
                    Creative
                  </ToggleButton>
                </ToggleButtonGroup>

                {alignment && (
                  <FormControl
                    variant="outlined"
                    sx={style.feild}
                    color="secondary"
                  >
                    <InputLabel id="subcategory-select-label">
                      Select Sub Category
                    </InputLabel>
                    <Select
                      labelId="subcategory-select-label"
                      value={post.subCategory}
                      onChange={handleSubcategoryChange}
                      label="Subcategory"
                    >
                      {subcategories[alignment].map((subcategory, index) => (
                        <MenuItem key={index} value={subcategory}>
                          {subcategory}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                )}
                <TextField
                  sx={style.feild}
                  id="outlined-basic"
                  label="Price"
                  variant="outlined"
                  color="secondary"
                  value={post.price}
                  onChange={(e) => {
                    postFeildsChange(e.target.value, "price");
                  }}
                />
                <TextField
                  id="outlined-basic"
                  label="Title"
                  variant="outlined"
                  color="secondary"
                  sx={style.feild}
                  value={post.title}
                  onChange={(e) => {
                    postFeildsChange(e.target.value, "title");
                  }}
                />
                <TextField
                  id="outlined-basic"
                  label="Description"
                  variant="outlined"
                  color="secondary"
                  multiline
                  sx={style.feild}
                  value={post.desc}
                  onChange={(e) => {
                    postFeildsChange(e.target.value, "desc");
                  }}
                />
                <TextField
                  id="outlined-basic"
                  label="ZIP Code"
                  variant="outlined"
                  color="secondary"
                  multiline
                  sx={style.feild}
                  value={post.zip}
                  onChange={(e) => {
                    postFeildsChange(e.target.value, "zip");
                  }}
                />
                <FormControl
                  variant="outlined"
                  color="secondary"
                  sx={style.feild}
                >
                  <InputLabel id="city-select-label">City</InputLabel>
                  <Select
                    labelId="city-select-label"
                    id="city-select"
                    value={post.city}
                    onChange={(e) => postFeildsChange(e.target.value, "city")}
                    label="City"
                  >
                    {cities.map((city, index) => (
                      <MenuItem key={index} value={city}>
                        {city}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Box>
            </Grid>
          </Grid>
          <Button onClick={submit} variant="contained" sx={style.btn}>
            PUBLISH
          </Button>
        </Box>
      </DashboardLayout>
    </>
  );
};

export default UserCreatePost;
const style = {
  heading: {
    fontFamily: "Poppins",
    fontWeight: 600,
    marginBottom: "25px",
    fontSize: "30px",
  },
  heading1: {
    fontFamily: "Poppins",
    fontWeight: 600,
    marginBottom: "25px",
    fontSize: "20px",
  },
  label: {
    fontFamily: "Poppins",
    fontWeight: 600,
  },
  feild: {
    marginY: "10px",
    width: "500px",
  },
  btn: {
    marginTop: "1rem",
    fontSize: "18px",
    fontFamily: "Poppins",
    fontWeight: 600,
    width: "20%",
    paddingY: "7px",
    background: "#323035",
    ":hover": {
      background: "#B327B0",
    },
  },
};
