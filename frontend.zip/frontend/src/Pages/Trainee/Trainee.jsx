import React from "react";
import Layout from "../../Components/Layout/Layout";
import { Box, Button, Container, Grid, Typography } from "@mui/material";
import traineeImage from "../../Assets/ProductIImages/Trainee.jpg"; // Renamed this to avoid conflict
import { Company } from "../../Components/Home/Company";
import TeamMembers from "../../Components/Common/TeamMembers";
import Stripe from "../../Components/Common/Stripe";

export const Trainee = () => {
  return (
    <Layout>
      <Stripe word={"Trainee Section"} />
      <Container
        sx={{
          maxWidth: { lg: "1450px" },
          paddingY: "3rem",
        }}
      >
        <Grid container spacing={5}>
          <Grid item lg={6} xs={12}>
            <Box
              sx={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <img
                data-aos="fade-right"
                data-aos-delay="900"
                src={traineeImage}  // Use the renamed variable here
                alt="Trainee"
                style={{
                  width: "100%",
                  height: "auto",
                  objectFit: "cover",
                  borderRadius: "1rem",
                }}
              />
            </Box>
          </Grid>
          <Grid item lg={6}>
            <Box
              sx={{
                padding: "20px",
                display: "flex",
                flexDirection: "column",
                alignItems: "start",
                justifyContent: "center",
              }}
            >
              <Typography
                sx={{
                  fontFamily: "Poppins",
                  fontSize: "28px",
                  fontWeight: 700,
                  textAlign: "left",
                }}
                data-aos="fade-up"
                data-aos-delay="700"
              >
                WELCOME TO ANTIQUE REVIEW SYSTEM
              </Typography>
              <Typography
                data-aos="fade-up"
                data-aos-delay="900"
                sx={{
                  fontFamily: "Poppins",
                  textAlign: "left",
                  paddingY: "16px",
                }}
              >
                Here We Introduce you with our System demonstration video (English)
              </Typography>
              <Typography
                data-aos="fade-up"
                data-aos-delay="1000"
                sx={{ fontFamily: "Poppins", textAlign: "left" }}
              >
                Here We Introduce you with our System demonstration video (Urdu)
              </Typography>
              <Button
                data-aos="fade-up"
                data-aos-delay="1200"
                variant="outlined"
                sx={{
                  marginTop: "20px",
                  paddingX: "20px",
                  fontWeight: 600,
                  fontFamily: "Poppins",
                  fontSize: "17px",
                  border: "1px solid black",
                  borderRadius: "5px",
                  transition: "all ease-out 0.5s",
                  color: "black",
                  opacity: 0.8,
                  ":hover": {
                    backgroundColor: "black",
                    border: "1px solid black",
                    color: "white",
                  },
                }}
              >
                READ MORE
              </Button>
            </Box>
          </Grid>
        </Grid>
        <TeamMembers />
      </Container>
      <Company />
    </Layout>
  );
};