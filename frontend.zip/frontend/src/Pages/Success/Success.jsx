import React, { useEffect, useState } from "react";
import Layout from "../../Components/Layout/Layout";
import { Button, Container, Typography } from "@mui/material";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import toast from "react-hot-toast";
import { createOrder } from "../../Components/Services/PostServices";

const Success = () => {
  const cart = useSelector((state) => state.cart.cart);
  const total = useSelector((state) => state.cart.total);
  const user = useSelector((state) => state.user.user);
  const [id, setId] = useState();
  const [hasCheckedOut, setHasCheckedOut] = useState(false);
  const checkout = () => {
    let temp = {
      cart,
      total,
      customerId: user?.id,
    };
    if (cart.length > 0 && !hasCheckedOut) {
      createOrder(temp).then((data) => {
        if (data.success == true) {
          toast.success("Order Placed Successfully");
          setId(data.orderId);

          setHasCheckedOut(true);
        } else {
          toast.error("Order Not Placed Successfully");
        }
      });
    }
  };

  useEffect(() => {
    if (user?.id) {
      checkout();
    }
  }, [user, hasCheckedOut]);
  return (
    <Layout>
      <Container sx={style.container}>
        <Typography
          sx={{
            fontFamily: "Poppins",
            textAlign: "center",
            fontWeight: 600,
            fontSize: "3rem",
          }}
        >
          Your Order Has Been Placed Successfully
        </Typography>
        <Button
          sx={{
            fontFamily: "Poppins",
            textAlign: "center",
            fontSize: "2rem",
          }}
          variant="outlined"
        >
          <Link to={"/"} style={{ textDecoration: "none", color: "inherit" }}>
            Back To Home
          </Link>
        </Button>
      </Container>
    </Layout>
  );
};

export default Success;
const style = {
  container: {
    maxWidth: { lg: "1350px" },
    marginY: "3rem",
    height: "50vh",
    display: "flex",
    alignItems: "center",
    flexDirection: "column",
  },
};
