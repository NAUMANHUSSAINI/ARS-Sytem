import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
} from "firebase/auth";
import { auth, db } from "../../Config/Config";
import { doc, getDoc, setDoc } from "firebase/firestore";

export const signUpWithEmailAndPassword = async (data) => {
  const { name, email, password, ConfrmPassword, address, postalCode } = data;
  return await createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      setDoc(doc(db, "users", userCredential?.user?.uid), {
        email: email?.trim(),
        address: address || "",
        photoURL: userCredential.photoURL || "",
        displayName: name || "",
        postalCode: postalCode || "",
      });

      return userCredential?.user?.uid;
    })
    .catch((error) => {
      const errorMessage = error.message;
      return "Email Already In Use";
    });
};

export const SignIn = async (data) => {
  const { email, password } = data;
  try {
    const userCredential = await signInWithEmailAndPassword(
      auth,
      email,
      password
    );
    const user = userCredential.user;
    if (user) {
      const docRef = doc(db, "users", user.uid);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const docData = docSnap.data();
        const dataWithId = { id: docSnap.id, ...docData };
        return dataWithId;
      } else {
        console.log("No such document!");
      }
    }
  } catch (error) {
    const errorCode = error.code;
    const errorMessage = error.message;
    return "Invalid Credentials";
  }
};

export const getUserById = async (id) => {
  const docRef = doc(db, "users", id);
  const docSnap = await getDoc(docRef);

  if (docSnap.exists()) {
    console.log("Document data:", docSnap.data());
  } else {
    console.log("No such document!");
  }
};
