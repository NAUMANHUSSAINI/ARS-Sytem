import {
  setDoc,
  doc,
  getDoc,
  getDocs,
  collection,
  addDoc,
  deleteDoc,
  query,
  orderBy,
  limit,
  serverTimestamp,
  where,
} from "firebase/firestore";
import { db } from "../../Config/Config";
export const CreatePost = async (item, postId) => {
  await addDoc(collection(db, "Posts"), { item, uid: postId });
};

export const getPostById = async (id) => {
  let temp = [];
  const querySnapshot = await getDocs(collection(db, "Posts"));
  querySnapshot.forEach((doc) => {
    if (doc.data().uid == id) {
      temp.push({ ...doc.data(), id: doc.id });
    }
  });
  return temp;
};

export const deletePost = async (docId) => {
  await deleteDoc(doc(db, "Posts", docId));
};
export const getApprovePosts = async () => {
  let temp = [];
  let creativePosts = [];
  let heritagePosts = [];
  let scrapyardPosts = [];
  const querySnapshot = await getDocs(collection(db, "Posts"));
  querySnapshot.forEach((doc) => {
    const post = doc.data().item.post;
    if (post.status === "approve") {
      const postData = { ...doc.data(), id: doc.id };
      temp.push(postData);
      if (post.category === "Creative") {
        creativePosts.push(postData);
      } else if (post.category === "Culture") {
        heritagePosts.push(postData);
      } else if (post.category === "Scrapyard") {
        scrapyardPosts.push(postData);
      }
    }
  });
  return { temp, creativePosts, heritagePosts, scrapyardPosts };
};
export const getProductByID = async (id) => {
  const docRef = doc(db, "Posts", id);
  const docSnap = await getDoc(docRef);

  if (docSnap.exists()) {
    return { ...docSnap.data(), id: docSnap.id };
  } else {
    console.log("No such document!");
    return false;
  }
};

export const sendContactForm = async (item) => {
  await addDoc(collection(db, "Contacts"), item);
};

export const createOrder = async (item) => {
  const { cart, total, customerId } = item;

  const ordersRef = collection(db, "Orders");

  try {
    const q = query(ordersRef, orderBy("orderId", "desc"), limit(1));
    const querySnapshot = await getDocs(q);
    let newOrderId = 1;
    if (!querySnapshot.empty) {
      const lastOrder = querySnapshot.docs[0].data();
      newOrderId = lastOrder.orderId + 1;
    }

    const newOrder = {
      orderId: newOrderId,
      items: cart,
      total: total,
      createdAt: serverTimestamp(),
      shippingStatus: "placed",
      customerId: customerId,
    };

    // Add new order to the collection
    await addDoc(ordersRef, newOrder);

    return { success: true, orderId: newOrderId };
  } catch (err) {
    console.error("Error creating order:", err);
    return { success: false, error: err.message };
  }
};

export const getUserOrders = async (uid) => {
  let temp = [];
  try {
    const q = query(collection(db, "Orders"), where("customerId", "==", uid));
    const querySnapshot = await getDocs(q);

    if (querySnapshot.empty) {
      console.log("No matching orders.");
      return temp;
    }

    querySnapshot.forEach((doc) => {
      temp.push({ ...doc.data(), id: doc.id });
    });
    console.log(temp, "temp order");
    return temp;
  } catch (error) {
    console.error("Error getting orders: ", error);
    return [];
  }
};
