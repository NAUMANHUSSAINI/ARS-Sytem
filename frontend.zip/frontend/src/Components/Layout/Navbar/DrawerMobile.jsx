import {
  Box,
  Divider,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
} from "@mui/material";
import React from "react";
import logo from "../../../Assets/ProductIImages/logoN.png";
import { Link } from "react-router-dom";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import AgricultureIcon from "@mui/icons-material/Agriculture";
import HandymanIcon from "@mui/icons-material/Handyman";
import EmojiObjectsIcon from "@mui/icons-material/EmojiObjects";
import CottageIcon from "@mui/icons-material/Cottage";
import InfoIcon from "@mui/icons-material/Info";

const DrawerMobile = () => {
  const Category = [
    {
      name: "CREATIVE",
      link: "/category?category=creative&subCategory=",
      icon: <EmojiObjectsIcon />,
    },
    {
      name: "SCRAPYARD",
      link: "/category?category=scrapyard&subCategory=",
      icon: <HandymanIcon />,
    },
    {
      name: "HERITAGE",
      link: "/category?category=heritage&subCategory=",
      icon: <AgricultureIcon />,
    },
    {
      name: "YOUR CART",
      link: "/",
      icon: <ShoppingCartIcon />,
    },
  ];
  const pages = [
    {
      name: "HOME",
      link: "/",
      icon: <CottageIcon />,
    },
    {
      name: "ABOUT US",
      link: "/about",
      icon: <InfoIcon />,
    },   
     {
      name: "Trainee Section",
      link: "/",
      icon: <CottageIcon />,
    },
  ];
  return (
    <>
      <Box sx={{ width: 250 }} role="presentation">
        <Box
          sx={{
            width: "100%",
            marginY: "30px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <img
            src={logo}
            alt="oops"
            style={{ width: "70px", height: "70px" }}
          />
        </Box>
        <Typography
          sx={{
            fontFamily: "Poppins",
            fontSize: 18,
            fontWeight: 600,
            paddingLeft: 3,
          }}
        >
          Category
        </Typography>
        <List>
          {Category.map((text, index) => (
            <ListItem key={index} disablePadding>
              <ListItemButton>
                <ListItemIcon>{text.icon}</ListItemIcon>
                <Link
                  to={text.link}
                  style={{ textDecoration: "none", color: "inherit" }}
                >
                  <ListItemText
                    primary={text.name}
                    sx={{ fontFamily: "Poppins" }}
                  />
                </Link>
              </ListItemButton>
            </ListItem>
          ))}
        </List>
        <Divider />
        <Typography
          sx={{
            fontFamily: "Poppins",
            fontSize: 18,
            fontWeight: 600,
            paddingLeft: 3,
          }}
        >
          Pages
        </Typography>
        <List>
          {pages.map((text, index) => (
            <ListItem key={index} disablePadding>
              <ListItemButton>
                <ListItemIcon> {text.icon}</ListItemIcon>
                <Link
                  to={text.link}
                  style={{ textDecoration: "none", color: "inherit" }}
                >
                  <ListItemText primary={text.name} />
                </Link>
              </ListItemButton>
            </ListItem>
          ))}
        </List>
      </Box>
    </>
  );
};

export default DrawerMobile;
