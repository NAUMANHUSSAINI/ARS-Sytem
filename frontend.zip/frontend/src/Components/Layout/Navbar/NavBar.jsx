import { Box, Button, Container, Grid, Typography } from "@mui/material";
import React, { useContext, useEffect, useState } from "react";
import logo from "../../../Assets/ProductIImages/logoN.png";
import { ImCart } from "react-icons/im";
import { IoIosArrowRoundForward } from "react-icons/io";
import { FaAngleDown } from "react-icons/fa";
import { Link } from "react-router-dom";
import { MyContext } from "../../../Context/userContext";
import { useNavigate } from "react-router-dom";

const mockCategory = [
  "Scrap Metal Recycling",
  "Junkyard Finds",
  "Vehicle Salvage",
  "Metal Scrapping",
  "Recycled Auto Parts",
  "Industrial Waste Management",
  "E-Waste Disposal",
  "Scrap Electronics Recycling",
  "Steel Scrap Processing",
  "Waste Material Recovery",
];
const mockCategory1 = [
  "Visual Arts",
  "Craft Making",
  "Graphic Design",
  "Digital Illustration",
  "Photography",
  "Creative Writing",
  "Music Composition",
  "Film Production",
  "Performing Arts",
  "Art Therapy",
];
export const NavBar = () => {
  const navigate = useNavigate();
  const creative = "linear-gradient(to bottom, #BCBEC0 , #FFFFFF)";
  const scrapyard = "linear-gradient(to bottom, #BCBEC0 , #FFFFFF)";
  const heritage = "linear-gradient(to bottom, #BCBEC0 , #FFFFFF)";
  const { value, setValue } = useContext(MyContext);
  const [activeType, setActiveType] = useState(value);
  useEffect(() => {
    setActiveType(value);
  }, [value]);
  return (
    <>
      <Box
        sx={[
          style.main,
          {
            background:
              activeType === "HERITAGE"
                ? heritage
                : activeType === "SCRAPYARD"
                ? scrapyard
                : activeType === "CREATIVE"
                ? creative
                : "white",
          },
        ]}
      >
        <Container sx={style.container}>
          <Box sx={style.navBarBox}>
            <Box sx={style.btnGroup}>
              <Button
                onClick={() => {
                  setValue("CREATIVE");
                  navigate(`/category?category=creative&subCategory=`);
                }}
                variant="outlined"
                sx={
                  value !== "" && value === "CREATIVE"
                    ? {
                        backgroundColor: "black",
                        color: "white",
                        paddingX: "20px",
                        fontWeight: 600,
                        fontFamily: "Poppins",
                        fontSize: "13px",
                        border: "1px solid black",
                        borderRadius: "5px",
                        transition: "all ease-out 0.5s",
                        boxShadow: 1,
                        ":hover": {
                          color: "black",
                          border: "1px solid black",
                        },
                      }
                    : style.btn
                }
              >
                <span>CREATIVE</span>
              </Button>

              <Button
                onClick={() => {
                  setValue("SCRAPYARD");
                  navigate(`/category?category=scrapyard&subCategory=`);
                }}
                variant="outlined"
                sx={
                  value !== "" && value === "SCRAPYARD"
                    ? {
                        backgroundColor: "black",
                        color: "white",
                        paddingX: "20px",
                        fontWeight: 600,
                        fontFamily: "Poppins",
                        fontSize: "13px",
                        border: "1px solid black",
                        borderRadius: "5px",
                        transition: "all ease-out 0.5s",
                        boxShadow: 1,
                        ":hover": {
                          color: "black",
                          border: "1px solid black",
                        },
                      }
                    : style.btn
                }
              >
                SCRAPYARD
              </Button>

              <Button
                onClick={() => {
                  setValue("HERITAGE");
                  navigate(`/category?category=heritage&subCategory=`);
                }}
                variant="outlined"
                sx={
                  value !== "" && value === "HERITAGE"
                    ? {
                        backgroundColor: "black",
                        color: "white",
                        paddingX: "20px",
                        fontWeight: 600,
                        fontFamily: "Poppins",
                        fontSize: "13px",
                        border: "1px solid black",
                        borderRadius: "5px",
                        transition: "all ease-out 0.5s",
                        boxShadow: 1,
                        ":hover": {
                          color: "black",
                          border: "1px solid black",
                        },
                      }
                    : style.btn
                }
              >
                HERITAGE
              </Button>
            </Box>
            <input
              className="input-grey-rounded"
              type="text"
              placeholder="Search For Products..."
            />
            <Link
              to={"/login"}
              style={{ textDecoration: "none", color: "inherit" }}
            >
              <Button variant="outlined" sx={style.btn}>
                LOGIN / SIGNUP
              </Button>
            </Link>

            <Link
              to={"/user-cart"}
              style={{ textDecoration: "none", color: "inherit" }}
            >
              <Button variant="outlined" sx={style.btn}>
                <ImCart style={{ marginRight: "3px" }} /> CART
              </Button>
            </Link>
          </Box>
        </Container>
        <Box
        // sx={[
        //   style.main,
        //   {
        //     background:
        //       activeType === "HERITAGE"
        //         ? heritage
        //         : activeType === "SCRAPYARD"
        //         ? scrapyard
        //         : activeType === "CREATIVE"
        //         ? creative
        //         : "white",
        //   },
        // ]}
        >
          <Container sx={style.container}>
            <Box sx={style.flexBox}>
              <img
                src={logo}
                alt="oops"
                style={{ width: "70px", height: "70px" }}
              />
              <Box sx={style.navItemsBox}>
                <Link style={{ textDecoration: "none" }} to={"/"}>
                  <Button variant="outlined" sx={style.btnNav}>
                    Home
                  </Button>
                </Link>
                <Link style={{ textDecoration: "none" }} to={"/about"}>
                  <Button variant="outlined" sx={style.btnNav}>
                    About
                  </Button>
                </Link>
                <Link style={{ textDecoration: "none" }} to={"/trainee"}>
                  <Button variant="outlined" sx={style.btnNav}>
                    Trainee Section
                  </Button>
                </Link>
                <Box sx={{ position: "relative" }} className="productNavClass">
                  <Button variant="outlined" sx={style.btnNav}>
                    Products <FaAngleDown style={{ marginLeft: "3px" }} />
                  </Button>
                  <Box sx={style.absoluteBox} className="productDropDown">
                    <Grid container>
                      <Grid item sm={4}>
                        <Typography sx={style.catHead}>
                          Creative Categories
                        </Typography>
                        <Box>
                          {mockCategory1.map((data, index) => {
                            return (
                              <>
                                <Box key={index} sx={style.listItems}>
                                  <IoIosArrowRoundForward />
                                  <Typography sx={style.text}>
                                    {data}
                                  </Typography>
                                </Box>
                              </>
                            );
                          })}
                        </Box>
                      </Grid>
                      <Grid item sm={4}>
                        <Typography sx={style.catHead}>
                          Scarpayard Categories
                        </Typography>
                        <Box>
                          {mockCategory.map((data, index) => {
                            return (
                              <>
                                <Box key={index} sx={style.listItems}>
                                  <IoIosArrowRoundForward />
                                  <Typography sx={style.text}>
                                    {data}
                                  </Typography>
                                </Box>
                              </>
                            );
                          })}
                        </Box>
                      </Grid>
                      <Grid item sm={4}>
                        <Typography sx={style.catHead}>
                          Culture Heritage Categories
                        </Typography>
                        <Box>
                          {mockCategory.map((data, index) => {
                            return (
                              <>
                                <Box key={index} sx={style.listItems}>
                                  <IoIosArrowRoundForward />
                                  <Typography sx={style.text}>
                                    {data}
                                  </Typography>
                                </Box>
                              </>
                            );
                          })}
                        </Box>
                      </Grid>
                    </Grid>
                  </Box>
                </Box>

                <Button variant="outlined" sx={style.btnNav}>
                  Shop
                </Button>
                <Link style={{ textDecoration: "none" }} to={"/contact"}>
                  <Button variant="outlined" sx={style.btnNav}>
                    Contact
                  </Button>
                </Link>
              </Box>
            </Box>
          </Container>
        </Box>
      </Box>
    </>
  );
};
const style = {
  listItems: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "start",
    gap: "10px",
    paddingBottom: "4px",
    width: "100%",
    cursor: "pointer",
    transition: "all ease-out 0.2s",
    ":hover": {
      color: "#f08934",
    },
    // paddingLeft: "10px",
  },
  text: {
    fontFamily: "Poppins",
  },
  main: {
    width: "100%",
    paddingY: "10px",
    // backgroundColor: "#FBF9F1",
  },
  container: {
    maxWidth: { lg: "1400px" },
    paddingX: "10px",
  },
  navBarBox: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: "14px",
  },
  btnGroup: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: "10px",
  },
  btn: {
    paddingX: "20px",
    fontWeight: 600,
    fontFamily: "Poppins",
    fontSize: "13px",
    border: "1px solid black",
    borderRadius: "5px",
    transition: "all ease-out 0.5s",
    color: "black",
    opacity: 0.8,
    // backgroundColor: "white",
    boxShadow: 1,
    ":hover": {
      backgroundColor: "black",
      border: "1px solid black",
      color: "white",
    },
  },
  btnNav: {
    paddingX: "20px",
    fontWeight: 700,
    fontFamily: "Poppins",
    fontSize: "15px",
    border: "none",
    transition: "all ease-out 0.5s",
    color: "black",
    opacity: 0.8,
    ":hover": {
      backgroundColor: "black",
      border: "none",
      color: "white",
      boxShadow: 1,
    },
  },
  navItemsBox: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "end",
    gap: "16px",
  },
  flexBox: {
    width: "100%",
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  absoluteBox: {
    position: "absolute",
    // top: 40,
    left: -460,
    boxShadow: 10,
    backgroundColor: "#FFF2E1",
    borderRadius: "5px",
    paddingY: "2rem",
    paddingX: "2rem",
    zIndex: 9999,
    width: "850px",
    // height: "400px",
  },
  catHead: {
    fontFamily: "Poppins",
    fontSize: "16px",
    fontWeight: 600,
    paddingBottom: "8px",
    // borderBottom: "1px solid black",
    // textDecoration: "underline",
    // color: "black",
    oapcity: 0.8,
    textAlign: "left",
    transition: "all ease-out 0.2s",
    ":hover": {
      color: "#f08934",
    },
  },
};
