import {
  Box,
  Button,
  Container,
  Drawer,
  Grid,
  Typography,
} from "@mui/material";
import React, { useContext, useEffect, useState } from "react";
import logo from "../../../Assets/ProductIImages/logoN.png";
import { IoIosArrowRoundForward } from "react-icons/io";
import { FaAngleDown } from "react-icons/fa";
import { Link, useLocation } from "react-router-dom";
import { MyContext } from "../../../Context/userContext";
import { useNavigate } from "react-router-dom";
import { CiMenuFries } from "react-icons/ci";
import { useSelector } from "react-redux";

import DrawerMobile from "./DrawerMobile";
import { getApprovePosts } from "../../Services/PostServices";

const mockCategory = [
  "Scrap Metal Recycling",
  "Junkyard Finds",
  "Vehicle Salvage",
  "Metal Scrapping",
  "Recycled Auto Parts",
  "Industrial Waste Management",
  "E-Waste Disposal",
  "Scrap Electronics Recycling",
  "Steel Scrap Processing",
  "Waste Material Recovery",
];
const mockCategory1 = [
  "Visual Arts",
  "Craft Making",
  "Graphic Design",
  "Digital Illustration",
  "Photography",
  "Creative Writing",
  "Music Composition",
  "Film Production",
  "Performing Arts",
  "Art Therapy",
];
const heritageC = ["Sindhi", "Islamabadi", "Quettawal", "Balochi", "Marwati"];
export const NavHome = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const { value, setValue } = useContext(MyContext);
  const [activeType, setActiveType] = useState(value);
  const user = useSelector((state) => state.user.user);
  const cart = useSelector((state) => state.cart.cart);
  const [allproducts, setAllProducts] = useState();
  const [searchResults, setSearchResults] = useState();

  const [open, setOpen] = React.useState(false);

  const toggleDrawer = (newOpen) => () => {
    setOpen(newOpen);
  };

  const allProducts = () => {
    getApprovePosts().then((data) => {
      setAllProducts(data.temp);
    });
  };

  const handleSearchProducts = (val) => {
    if (!val) {
      setSearchResults([]);
    } else {
      const filteredProducts = allproducts?.filter((product) =>
        product.item.post.title.toLowerCase().includes(val.toLowerCase())
      );
      setSearchResults(filteredProducts);
    }
  };
  useEffect(() => {
    setActiveType(value);
  }, [value]);
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const categoryParam = searchParams.get("category");

    if (categoryParam) {
      setValue(categoryParam.toUpperCase());
    }
  }, [location.search]);
  useEffect(() => {
    allProducts();
  }, []);
  return (
    <>
      <Box sx={[style.main]}>
        <Container sx={style.container}>
          <Box sx={style.navBarBox}>
            <Box
              sx={{ display: { md: "none", xs: "block" }, marginRight: "auto" }}
            >
              <img
                src={logo}
                alt="oops"
                style={{ width: "70px", height: "70px" }}
              />
            </Box>
            <Box sx={style.btnGroup}>
              <Button
                onClick={() => {
                  setValue("CREATIVE");
                  navigate(`/category?category=creative&subCategory=`);
                }}
                variant="outlined"
                sx={
                  value !== "" && value === "CREATIVE"
                    ? {
                        backgroundColor: "black",
                        color: "white",
                        paddingX: "20px",
                        fontWeight: 600,
                        fontFamily: "Poppins",
                        fontSize: "13px",
                        border: "1px solid black",
                        borderRadius: "5px",
                        transition: "all ease-out 0.5s",
                        display: { md: "block", xs: "none" },
                        boxShadow: 1,
                        ":hover": {
                          color: "black",
                          border: "1px solid black",
                        },
                      }
                    : style.btn
                }
              >
                <span>CREATIVE</span>
              </Button>

              <Button
                onClick={() => {
                  setValue("SCRAPYARD");
                  navigate(`/category?category=scrapyard&subCategory=`);
                }}
                variant="outlined"
                sx={
                  value !== "" && value === "SCRAPYARD"
                    ? {
                        backgroundColor: "black",
                        color: "white",
                        paddingX: "20px",
                        fontWeight: 600,
                        fontFamily: "Poppins",
                        fontSize: "13px",
                        border: "1px solid black",
                        borderRadius: "5px",
                        transition: "all ease-out 0.5s",
                        display: { md: "block", xs: "none" },
                        boxShadow: 1,
                        ":hover": {
                          color: "black",
                          border: "1px solid black",
                        },
                      }
                    : style.btn
                }
              >
                SCRAPYARD
              </Button>

              <Button
                onClick={() => {
                  setValue("HERITAGE");
                  navigate(`/category?category=heritage&subCategory=`);
                }}
                variant="outlined"
                sx={
                  value !== "" && value === "HERITAGE"
                    ? {
                        backgroundColor: "black",
                        color: "white",
                        paddingX: "20px",
                        fontWeight: 600,
                        fontFamily: "Poppins",
                        fontSize: "13px",
                        border: "1px solid black",
                        borderRadius: "5px",
                        transition: "all ease-out 0.5s",
                        display: { md: "block", xs: "none" },
                        boxShadow: 1,
                        ":hover": {
                          color: "black",
                          border: "1px solid black",
                        },
                      }
                    : style.btn
                }
              >
                HERITAGE
              </Button>
            </Box>
            <Box sx={{ position: "relative", width: "40%" }}>
              <input
                className="input-grey-rounded"
                type="text"
                placeholder="Search For Products..."
                onChange={(e) => handleSearchProducts(e.target.value)}
              />
              {searchResults && searchResults.length > 0 && (
                <Box
                  sx={{
                    position: "absolute",
                    boxShadow: 10,
                    backgroundColor: "#EFF0F0",
                    borderRadius: "5px",
                    paddingY: "2rem",
                    paddingX: "1rem",

                    width: "380px",
                    zIndex: 99,
                    left: "1rem",
                  }}
                >
                  {searchResults.map((data, index) => {
                    return (
                      <>
                        <Box
                          key={index}
                          sx={{
                            padding: "4px",
                            width: "100%",
                            display: "flex",
                            flexDirection: "row",
                            alignItems: "center",
                            justifyContent: "space-between",
                            cusror: "pointer",
                            ":hover": {
                              background: "#EEF7FF",
                            },
                          }}
                          onClick={() => {
                            navigate(`/singleProduct?ID=${data.id}`);
                            setSearchResults([]);
                          }}
                        >
                          <Typography
                            sx={{
                              cusror: "pointer",
                              fontFamily: "Poppins",
                              fontWeight: 600,
                            }}
                          >
                            {data.item.post.title}
                          </Typography>
                          <Typography
                            sx={{
                              cusror: "pointer",
                              fontFamily: "Poppins",
                              fontWeight: 600,
                            }}
                          >
                            RS.{data.item.post.price}
                          </Typography>
                        </Box>
                      </>
                    );
                  })}
                </Box>
              )}
            </Box>
            {!user ? (
              <Link
                to={"/login"}
                style={{ textDecoration: "none", color: "inherit" }}
              >
                <Button variant="outlined" sx={style.btn}>
                  LOGIN
                </Button>
              </Link>
            ) : (
              <Link
                to={"/dashboard/user-ads-listings"}
                style={{ textDecoration: "none", color: "inherit" }}
              >
                <Button variant="outlined" sx={style.btn}>
                  Dashboard
                </Button>
              </Link>
            )}
            <Button
              variant="outlined"
              sx={style.btn}
              onClick={() => {
                navigate("/user-cart");
              }}
            >
              CART {cart.length > 0 && cart.length}
            </Button>
            <Box
              sx={{ display: { md: "none", xs: "block" }, marginLeft: "auto" }}
              onClick={toggleDrawer(true)}
            >
              <CiMenuFries style={{ color: "black", fontSize: 25 }} />
            </Box>
          </Box>
        </Container>
      </Box>
      <Box sx={[style.main, { display: { md: "block", xs: "none" } }]}>
        <Container sx={style.container}>
          <Box sx={style.flexBox}>
            <img
              src={logo}
              alt="oops"
              style={{ width: "70px", height: "70px" }}
            />
            <Box sx={style.navItemsBox}>
              <Link style={{ textDecoration: "none" }} to={"/"}>
                <Button variant="outlined" sx={style.btnNav}>
                  Home
                </Button>
              </Link>
              <Link style={{ textDecoration: "none" }} to={"/about"}>
                <Button variant="outlined" sx={style.btnNav}>
                  About
                </Button>
              </Link>
              <Link style={{ textDecoration: "none" }} to={"/trainee"}>
                <Button variant="outlined" sx={style.btnNav}>
                  Trainee Section
                </Button>
              </Link>
              <Box sx={{ position: "relative" }} className="productNavClass">
                <Button variant="outlined" sx={style.btnNav}>
                  Products <FaAngleDown style={{ marginLeft: "3px" }} />
                </Button>
                <Box sx={style.absoluteBox} className="productDropDown">
                  <Grid container>
                    <Grid item sm={4}>
                      <Typography sx={style.catHead}>
                        Creative Categories
                      </Typography>
                      <Box>
                        {mockCategory1.map((data, index) => {
                          return (
                            <>
                              <Link
                                style={{
                                  textDecoration: "none",
                                  color: "inherit",
                                }}
                                to={`/category?category=creative&subCategory=${data}`}
                                key={index}
                              >
                                <Box sx={style.listItems}>
                                  <IoIosArrowRoundForward />
                                  <Typography sx={style.text}>
                                    {data}
                                  </Typography>
                                </Box>
                              </Link>
                            </>
                          );
                        })}
                      </Box>
                    </Grid>
                    <Grid item sm={4}>
                      <Typography sx={style.catHead}>
                        Scarpayard Categories
                      </Typography>
                      <Box>
                        {mockCategory.map((data, index) => {
                          return (
                            <>
                              <Link
                                style={{
                                  textDecoration: "none",
                                  color: "inherit",
                                }}
                                to={`/category?category=scrapyard&subCategory=${data}`}
                                key={index}
                              >
                                <Box sx={style.listItems}>
                                  <IoIosArrowRoundForward />
                                  <Typography sx={style.text}>
                                    {data}
                                  </Typography>
                                </Box>
                              </Link>
                            </>
                          );
                        })}
                      </Box>
                    </Grid>
                    <Grid item sm={4}>
                      <Typography sx={style.catHead}>
                        Culture Heritage Categories
                      </Typography>
                      <Box>
                        {heritageC.map((data, index) => {
                          return (
                            <>
                              <Link
                                style={{
                                  textDecoration: "none",
                                  color: "inherit",
                                }}
                                to={`/category?category=heritage&subCategory=${data}`}
                              >
                                <Box key={index} sx={style.listItems}>
                                  <IoIosArrowRoundForward />
                                  <Typography sx={style.text}>
                                    {data}
                                  </Typography>
                                </Box>
                              </Link>
                            </>
                          );
                        })}
                      </Box>
                    </Grid>
                  </Grid>
                </Box>
              </Box>

              <Link style={{ textDecoration: "none" }} to={"/contact"}>
                <Button variant="outlined" sx={style.btnNav}>
                  Contact
                </Button>
              </Link>
            </Box>
          </Box>
        </Container>
      </Box>
      {/* Drawer Mobile Screen */}
      <Drawer open={open} onClose={toggleDrawer(false)}>
        <DrawerMobile />
      </Drawer>
    </>
  );
};
const style = {
  listItems: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "start",
    gap: "10px",
    paddingBottom: "4px",
    width: "100%",
    cursor: "pointer",
    transition: "all ease-out 0.2s",
    ":hover": {
      color: "#f08934",
    },
  },
  text: {
    fontFamily: "Poppins",
  },
  main: {
    width: "100%",
    paddingY: "10px",
  },
  container: {
    maxWidth: { lg: "1400px" },
    paddingX: "10px",
  },
  navBarBox: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: { md: "center", xs: "space-between" },
    gap: "14px",
    width: "100%",
  },
  btnGroup: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: "10px",
  },
  btn: {
    paddingX: "20px",
    fontWeight: 600,
    fontFamily: "Poppins",
    fontSize: "13px",
    border: "1px solid black",
    borderRadius: "5px",
    transition: "all ease-out 0.5s",
    color: "black",
    opacity: 0.8,
    display: { md: "block", xs: "none" },
    boxShadow: 1,
    ":hover": {
      backgroundColor: "black",
      border: "1px solid black",
      color: "white",
    },
  },
  btnNav: {
    paddingX: "20px",
    fontWeight: 700,
    fontFamily: "Poppins",
    fontSize: "15px",
    border: "none",
    transition: "all ease-out 0.5s",
    color: "black",
    opacity: 0.8,
    ":hover": {
      backgroundColor: "black",
      border: "none",
      color: "white",
      boxShadow: 1,
    },
  },
  navItemsBox: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "end",
    gap: "16px",
  },
  flexBox: {
    width: "100%",
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  absoluteBox: {
    position: "absolute",
    left: -360,
    boxShadow: 10,
    backgroundColor: "#FFF2E1",
    borderRadius: "5px",
    paddingY: "2rem",
    paddingX: "2rem",
    zIndex: 9999,
    width: "850px",
  },
  catHead: {
    fontFamily: "Poppins",
    fontSize: "16px",
    fontWeight: 600,
    paddingBottom: "8px",
    oapcity: 0.8,
    textAlign: "left",
    transition: "all ease-out 0.2s",
    ":hover": {
      color: "#f08934",
    },
  },
};
