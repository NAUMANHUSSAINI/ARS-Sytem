import React from "react";
import { Box, Button, Container, Grid, Typography } from "@mui/material";
import logo from "../../../Assets/logoWN.png";
export const Footer = () => {
  const listOne = [
    "Creative Store",
    "Your Cart",
    "Your Order",
    "Your Payments",
    "Scrapyard",
  ];
  const pages = ["Home", "About","Trainee Section", "Services", "Contact Us"];
  return (
    <>
      <Box sx={style.mainBox}>
        <Container sx={style.container}>
          <Grid container spacing={5}>
            <Grid item lg={4} xs={12}>
              <img src={logo} style={{ width: "200px", height: "auto" }} />
            </Grid>
            <Grid item lg={5} md={9} xs={12}>
              <Box
                sx={{
                  width: "100%",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: { md: "start", xs: "center" },
                  justifyContent: "center",
                }}
              >
                <Typography sx={style.headings}>
                  {" "}
                  ANTIQUE REVIEW SYSTEM
                </Typography>
                {listOne.map((data, index) => {
                  return (
                    <React.Fragment key={index}>
                      <Typography sx={style.list}>{data}</Typography>
                    </React.Fragment>
                  );
                })}
              </Box>
            </Grid>
            <Grid item lg={3} md={3} xs={12}>
              <Box
                sx={{
                  width: "100%",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: { md: "start", xs: "center" },
                  justifyContent: "center",
                }}
              >
                <Typography sx={style.headings}> PAGES</Typography>
                {pages.map((data, index) => {
                  return (
                    <React.Fragment key={index}>
                      <Typography sx={style.list}>{data}</Typography>
                    </React.Fragment>
                  );
                })}
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </>
  );
};
const style = {
  mainBox: {
    paddingY: "3rem",
    background: "#413E43",
  },
  container: {
    maxWidth: { lg: "1450px" },
  },
  headings: {
    fontFamily: "Poppins",
    fontSize: { sm: "35px", xs: "22px" },
    fontWeight: 600,
    paddignY: "1rem",
    color: "white",
    textAlign: "left",
  },
  list: {
    fontFamily: "Poppins",
    color: "white",
    paddingY: "5px",
    fontSize: "17px",
    transition: "all ease-out 0.4s",
    cursor: "pointer",
    textAlign: "left",

    ":hover": {
      color: "#EF8031",
    },
  },
};
