import React from "react";
import { NavBar } from "./Navbar/NavBar";
import { Footer } from "./Footer/Footer";
import { NavHome } from "./Navbar/NavHome";

const Layout = ({ children }) => {
  return (
    <>
      {/* <NavBar /> */}
      <NavHome />
      {children}
      <Footer />
    </>
  );
};

export default Layout;
