import { Box, Container, Typography } from "@mui/material";
import React from "react";

const Stripe = ({ word }) => {
  return (
    <>
      <Box sx={style.strip}>
        <Container sx={style.container}>
          <Typography
            sx={style.stripText}
            data-aos="fade-up"
            data-aos-delay="500"
          >
            {word}
          </Typography>
        </Container>
      </Box>
    </>
  );
};

export default Stripe;
const style = {
  container: {
    maxWidth: { lg: "1450px" },
    paddingY: "3rem",
  },
  strip: {
    background: "#413E43",
  },
  stripText: {
    color: "white",
    fontFamily: "Poppins",
    fontSize: "30px",
    fontWeight: 600,
    letterSpacing: "2px",
    textAlign: "left",
    textTransform: "uppercase",
  },
};
