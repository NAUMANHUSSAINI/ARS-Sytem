import { Box, Container, Grid, Typography } from "@mui/material";
import React from "react";
import { IoLocationSharp } from "react-icons/io5";

const QuickAddress = () => {
  return (
    <>
      <Box>
        <Container sx={style.container}>
          <Grid
            container
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Grid item lg={4} md={6} xs={12}>
              <Box sx={style.Qbox}>
                <Typography sx={style.head}>Address</Typography>
                <Typography sx={style.subHead}>
                  {" "}
                  <IoLocationSharp
                    style={{
                      color: "#ef8031",
                      fontSize: 18,
                      marginRight: "5px",
                    }}
                  />{" "}
                  2779 Oakwood Avenue NY
                </Typography>
              </Box>
            </Grid>
            <Grid item lg={4} md={6} xs={12}>
              <Box sx={style.Qbox}>
                <Typography sx={style.head}>Phone</Typography>
                <Typography sx={style.subHead}>
                  {" "}
                  <IoLocationSharp
                    style={{
                      color: "#ef8031",
                      fontSize: 18,
                      marginRight: "5px",
                    }}
                  />{" "}
                  212-631-5135 <br />{" "}
                  <span style={{ paddingLeft: "30px" }}>212-631-5105</span>
                </Typography>
              </Box>
            </Grid>
            <Grid item lg={4} md={6} xs={12}>
              <Box sx={style.Qbox}>
                <Typography sx={style.head}>E-mail</Typography>
                <Typography sx={style.subHead}>
                  {" "}
                  <IoLocationSharp
                    style={{
                      color: "#ef8031",
                      fontSize: 18,
                      marginRight: "5px",
                    }}
                  />{" "}
                  sales@qntiquerevioewsystem.com
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </>
  );
};

export default QuickAddress;
const style = {
  container: {
    maxWidth: { lg: "1450px" },
  },
  Qbox: {
    padding: "25px",
    display: "flex",
    flexDirection: "column",
    alignItems: { md: "start", xs: "center" },
    gap: "7px",
  },
  head: {
    fontFamily: "Poppins",
    color: "#ef8031",
    fontWeight: 600,
    fontSize: "30px",
  },
  subHead: {
    fontFamily: "Poppins",
    opacity: 0.8,
    fontSize: { sm: "18px", xs: "14px" },
  },
};
