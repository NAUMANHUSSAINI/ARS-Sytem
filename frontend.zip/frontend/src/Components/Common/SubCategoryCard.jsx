import React from "react";
import { Box, Container, Typography } from "@mui/material";
import { Link } from "react-router-dom";

const SubCategoryCard = ({ src, head }) => {
  return (
    <Box sx={style.card}>
      <img
        alt="oops"
        src={src}
        style={{
          borderRadius: "20px",
          width: "100%",
          height: "100%",
          objectFit: "cover",
        }}
      />
      <Box sx={style.contentBox}>
        <Link
          style={{ textDecoration: "none" }}
          to={`/category?category=creative&subCategory=${head}`}
        >
          <Typography sx={style.badge}>{head}</Typography>
        </Link>
        <Typography>
          Lorem ipsum is placeholder text commonly used in the graphic
        </Typography>
      </Box>
    </Box>
  );
};

export default SubCategoryCard;
const style = {
  card: {
    // width: "350px",
    // height: "520px",
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    borderRadius: "20px",
    position: "relative",
    transform: "scale(0.95)",
    transition: "all ease-out 0.6s",
    ":hover": {
      transform: "scale(1)",
    },
  },
  contentBox: {
    position: "absolute",
    right: 0,
    left: 0,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    color: "white",
    paddingY: "2rem",
    paddingX: "10px",
  },
  badge: {
    fontFamily: "Poppins",
    fontWeight: 600,
    fontSize: 26,
    color: "#EF8031",
  },
};
