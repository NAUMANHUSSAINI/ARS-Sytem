import React from "react";
import { Box, Container, Typography, Chip } from "@mui/material";
import product from "../../Assets/ProductIImages/dryer.webp";
import { FiHeart } from "react-icons/fi";
import Rating from "@mui/material/Rating";
import { Link } from "react-router-dom";

const ProductCard = ({ src }) => {
  return (
    <>
      <Box sx={style.card} className="cardProdd">
        <Box sx={{ position: "relative" }}>
          <img
            src={src?.item?.imageUrls[0]}
            alt="oops"
            style={{ width: "100%", height: "300px", borderRadius: "1rem" }}
          />
        </Box>

        <Box sx={style.content}>
          <Box sx={style.ChipBox}>
            <Chip
              label={src?.item?.post?.category}
              sx={{
                background: "#5D5C63",
                color: "white",
                fontFamily: "Poppins",
              }}
            />
          </Box>
          <Link
            style={{ textDecoration: "none", color: "inherit" }}
            to={`/singleProduct?ID=${src?.id}`}
          >
            <Typography sx={style.name}>{src?.item?.post?.title}</Typography>
          </Link>
          <Typography sx={style.price}>RS. {src?.item?.post?.price}</Typography>
          {/* <Rating name="simple-controlled" value={5} /> */}
        </Box>
        <Box sx={style.saleBox}>
          <Typography
            sx={{ fontFamily: "Poppins", color: "white", fontWeight: 600 }}
          >
            SALE
          </Typography>
        </Box>
        <Box sx={style.favioirateBox} className="favBox">
          <FiHeart style={{ fontSize: 22 }} />
        </Box>
      </Box>
    </>
  );
};

export default ProductCard;
const style = {
  card: {
    borderRadius: "1rem",
    padding: "12px",
    // boxShadow: 7,
    marginY: "2rem",
    overflowX: "hidden",
    backgroundColor: "white",
    position: "relative",
    boxShadow:
      " rgba(14, 30, 37, 0.12) 0px 2px 4px 0px, rgba(14, 30, 37, 0.2) 0px 2px 16px 0px",
  },
  content: {
    paddingY: "1rem",
    display: "flex",
    flexDirection: "column",
    width: "100%",
    paddingX: "12px",
  },
  ChipBox: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "start",
    gap: "10px",
    marginTop: "10px",
    width: "100%",
    flexWrap: "wrap",
  },
  name: {
    textAlign: "left",
    fontWeight: 600,
    fontFamily: "Poppins",
    fontSize: 20,
    opacity: 0.8,
    marginTop: "5px",
  },
  price: {
    textAlign: "left",
    fontWeight: 600,
    fontFamily: "Poppins",
    fontSize: 20,
    opacity: 0.8,
  },
  saleBox: {
    paddingX: "10px",
    paddingY: "3px",
    background: "#EF8031",
    position: "absolute",
    right: 20,
    top: "5%",
    borderRadius: "5px",
  },
  favioirateBox: {
    position: "absolute",
    borderRadius: "5px",

    background: "rgba(0, 0, 0, 0.7)",
    border: "1px solid rgba(255, 255, 255, 0.18)",

    backdropFilter: "blur(6.5px)",
    paddingX: "10px",
    paddingY: "8px",
    color: "white",
    top: "5%",
    transition: "all ease-in 0.3s",
    ":hover": {
      background: "#EF8031",
    },
  },
};
