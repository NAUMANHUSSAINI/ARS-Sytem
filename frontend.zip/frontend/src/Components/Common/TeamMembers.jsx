import { Box, Grid, Typography } from "@mui/material";
import React from "react";
import t1 from "../../Assets/user.jfif";
import t2 from "../../Assets/noman.jpeg";
import { FaLinkedinIn } from "react-icons/fa";
import { FaFacebookF } from "react-icons/fa";
import { FaGooglePlusG } from "react-icons/fa6";

const TeamMembers = () => {
  const tem = [
    {
      src: t1,
      name: " BAKHTAWAR CHANGEZI",
      role: "CEO",
    },
    {
      src: t2,
      name: "RAMSHA ANWAR",
      role: "CEO",
    },
    {
      src: t1,
      name: "NAUMAN HUSSAINI",
      role: "CEO",
    },
    {
      src: t1,
      name: "MUHAMMAD SHAHMEER",
      role: "CEO",
    },
  ];
  return (
    <>
      <Box sx={style.box}>
        <Typography sx={style.heading} data-aos="fade-up" data-aos-delay="500">
          Team Memebers
        </Typography>
        <Grid
          container
          spacing={3}
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {tem.map((data) => {
            return (
              <>
                <Grid item lg={3} md={4} sm={6} xs={12}>
                  <Box sx={style.teamCard}>
                    <img
                      src={data.src}
                      style={{
                        width: "100%",
                        paddingBottom: "5rem",
                        height: "350px",
                      }}
                    />
                    <Box sx={style.absoluteBox}>
                      <Typography
                        sx={[style.txt, { fontWeight: 600 }]}
                        data-aos="fade-up"
                        data-aos-delay="1000"
                      >
                        {data.name}
                      </Typography>

                      <Box sx={style.socialIcons}>
                        <Box sx={style.social}>
                          <FaLinkedinIn style={{ fontSize: 18 }} />
                        </Box>
                        <Box sx={style.social}>
                          <FaFacebookF style={{ fontSize: 18 }} />
                        </Box>
                        <Box sx={style.social}>
                          <FaGooglePlusG style={{ fontSize: 18 }} />
                        </Box>
                      </Box>
                    </Box>
                  </Box>
                </Grid>
              </>
            );
          })}
        </Grid>
      </Box>
    </>
  );
};

export default TeamMembers;
const style = {
  box: {
    marginY: "3rem",
  },
  heading: {
    fontSize: "40px",
    fontFamily: "Poppins",
    paddingY: "2rem",
    fontWeight: 700,
  },
  teamCard: {
    textAlign: "left", // Align text to the left
    marginBottom: "30px",
    boxShadow: 3,
    position: "relative",
    overflow: "hidden",
  },
  absoluteBox: {
    position: "absolute",
    bottom: 10,
    left: 20,
    zIndex: 999,
  },
  txt: {
    color: "black",
    fontFamily: "Poppins",
    fontSize: "22px",
  },
  socialIcons: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: "10px",
    marginTop: "8px",
    width: "100%",
  },
  social: {
    paddingY: "5px",
    paddingX: "8px",
    borderRadius: "5px",
    color: "white",
    backgroundColor: "#ef8031",
    transition: "all ease-out 0.5s",
    ":hover": {
      backgroundColor: "black",
    },
  },
};
