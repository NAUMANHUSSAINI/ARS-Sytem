import React from "react";
import { Box, Container, Typography, Button, Grid } from "@mui/material";
import c1 from "../../Assets/ProductIImages/c1.png";
import c2 from "../../Assets/ProductIImages/c2.png";
import c3 from "../../Assets/ProductIImages/c3.png";
import c4 from "../../Assets/ProductIImages/c4.png";
import c5 from "../../Assets/ProductIImages/c5.png";

export const Company = () => {
  return (
    <Box sx={style.mainBox}>
      <Container sx={style.container}>
        <Grid
          container
          columnSpacing={10}
          sx={{ display: "flex", justifyContent: "center" }}
        >
          <Grid item>
            <img src={c1} />
          </Grid>
          <Grid item>
            <img src={c2} />
          </Grid>
          <Grid item>
            <img src={c3} />
          </Grid>
          <Grid item>
            <img src={c4} />
          </Grid>
          <Grid item>
            <img src={c5} />
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};
const style = {
  mainBox: {
    paddingY: "3rem",
  },
  container: {
    maxWidth: { lg: "1450px" },
  },
};
