import React, { useContext, useEffect, useState } from "react";
import { Box, Container, Typography, Button } from "@mui/material";
import { Swiper, SwiperSlide } from "swiper/react";
import x1 from "../../Assets/ProductIImages/x1.avif";
import x2 from "../../Assets/ProductIImages/x2.avif";
import x3 from "../../Assets/ProductIImages/x3.avif";
import x4 from "../../Assets/ProductIImages/x4.avif";
import x5 from "../../Assets/ProductIImages/x5.avif";
import x6 from "../../Assets/ProductIImages/x6.avif";

// Import Swiper styles
import "swiper/css";
import ProductCard from "../Common/ProductCard";
const CategorySlider = ({ heading, items }) => {
  const images = [x1, x2, x3, x4, x5, x6];

  return (
    <>
      <Box sx={style.mainBox}>
        <Container sx={style.container}>
          <Typography
            sx={style.heading}
            data-aos="fade-up"
            data-aos-delay="500"
          >
            {heading}
          </Typography>
          <Box data-aos="fade-up" data-aos-delay="800">
            <Swiper
              spaceBetween={50}
              slidesPerView={4}
              breakpoints={{
                1200: {
                  slidesPerView: 4,
                },
                900: {
                  slidesPerView: 3,
                },
                625: {
                  slidesPerView: 2,
                },
                300: {
                  slidesPerView: 1,
                },
              }}
            >
              {items &&
                items?.map((data) => {
                  return (
                    <SwiperSlide style={{ overflow: "hidden" }}>
                      <ProductCard src={data} />
                    </SwiperSlide>
                  );
                })}
            </Swiper>
          </Box>
          <Button variant="outlined" sx={style.btn}>
            View More
          </Button>
        </Container>
      </Box>
    </>
  );
};

export default CategorySlider;
const style = {
  mainBox: {
    paddingY: "2rem",
  },
  container: {
    maxWidth: { lg: "1450px" },
  },
  heading: {
    fontSize: "40px",
    fontFamily: "Poppins",
    paddingY: "2rem",
    fontWeight: 700,
  },
  btn: {
    paddingX: "20px",
    fontWeight: 600,
    fontFamily: "Poppins",
    fontSize: "13px",
    border: "1px solid black",
    borderRadius: "5px",
    transition: "all ease-out 0.5s",
    color: "black",
    opacity: 0.8,
    // backgroundColor: "white",
    boxShadow: 1,
    ":hover": {
      backgroundColor: "black",
      border: "1px solid black",
      color: "white",
    },
  },
};
