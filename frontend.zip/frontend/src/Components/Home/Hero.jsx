import React, { useContext } from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from "react-responsive-carousel";
import slider1 from "../../Assets/ProductIImages/p1.avif";
import slider2 from "../../Assets/ProductIImages/p3.avif";
import slider3 from "../../Assets/ProductIImages/p2.avif";
import { Box, Button, Container, Typography } from "@mui/material";
import { motion } from "framer-motion";
import { Reveal } from "../../Utils/Reveal";
import { useNavigate } from "react-router-dom";
import { MyContext } from "../../Context/userContext";

function Hero() {
  const style = {
    overText: {
      position: "absolute",
      width: { md: "60%", xs: "70%" },
      top: { md: "11.5rem", xs: "2.5rem" },
      left: { lg: "15rem", md: "10rem", xs: "5rem" },
      right: 0,
      bottom: 0,
      textAlign: "left",
      height: "100%",
      zIndex: 3,
    },
    subBox: { textAlign: "left" },
    welcome: {
      textAlign: "left",
      animation: "text-appear 1.2s linear forwards",
      animationDelay: "0.7s",
      color: "white",
      fontSize: { md: "1.34rem", xs: "1rem" },
      fontWeight: 600,
      letterSpacing: "4px",
      fontFamily: "Poppins",
    },
    ComName: {
      fontFamily: "Poppins",
      textAlign: "left",
      animation: "text-appear 1.2s linear forwards",
      animationDelay: "0.7s",
      fontWeight: 900,
      fontSize: { lg: "80px", md: "50px", xs: "25px" },
      color: "white",
      ":: before": {
        content: "' '",
        position: "absolute",
        backgroundColor: "#EF8031",
        color: "#EF8031",
        width: "5px",
        height: { lg: "94px", md: "60px", xs: "40px" },
        left: "-15px",
      },
    },
    para: {
      fontSize: { md: "18px", xs: "13px" },
      color: "white",
      textAlign: "left",
      marginY: "1rem",
    },
    button: {
      marginY: { md: "1rem", xs: "0px" },
      backgroundColor: "#F08734",
      color: "white",
      paddingX: "1.5rem",
      paddingY: { md: "1rem", xs: "10px" },
      fontSize: { md: "1rem", xs: "13px" },
      fontFamily: "Poppins",
      ":hover": {
        backgroundColor: "#EF8031",
        boxShadow: 5,
      },
    },
    largescreen: {
      display: { md: "block", xs: "none" },
      marginTop: "2rem",
    },
    smallScreen: {
      display: { md: "none", xs: "block" },
    },
  };
  const navigate = useNavigate();
  const { value, setValue } = useContext(MyContext);

  return (
    <>
      <Box sx={style.largescreen}>
        <Container sx={{ maxWidth: { lg: "1450px" } }}>
          <Carousel
            showArrows={true}
            showIndicators={false}
            infiniteLoop={true}
            showThumbs={false}
          >
            <div style={{ position: "relative" }}>
              <Box
                sx={{
                  background: "black",
                  opacity: 0.6,
                  position: "absolute",
                  left: 0,
                  right: 0,
                  top: 0,
                  bottom: 0,
                  zIndex: 1,
                  borderRadius: "40px",
                }}
              ></Box>
              <img
                src={slider1}
                style={{
                  width: "100%",
                  height: "700px",
                  position: "relative",
                  zIndex: -1,
                  objectFit: "cover",
                  borderRadius: "40px",
                }}
                alt="log home repair and restoration"
              />
              {/* <Container
              sx={{
                maxWidth: { lg: "1450px" },
              }}
            > */}
              <Box sx={style.overText}>
                <Box sx={style.subBox}>
                  <Typography variant="h5" sx={style.welcome}>
                    EXPLORE OUR
                  </Typography>
                  <Reveal>
                    <Typography variant="h3" sx={style.ComName}>
                      CREATIVE
                    </Typography>
                  </Reveal>
                </Box>
                <Typography sx={style.para}>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen book.
                </Typography>
                <Button
                  onClick={() => {
                    setValue("CREATIVE");
                    navigate(`/category?category=creative&subCategory=`);
                  }}
                  variant="contained"
                  sx={style.button}
                >
                  EXPLORE MORE
                </Button>
              </Box>
              {/* </Container> */}
            </div>
            <div style={{ position: "relative" }}>
              <Box
                sx={{
                  background: "black",
                  opacity: 0.5,
                  position: "absolute",
                  left: 0,
                  right: 0,
                  top: 0,
                  bottom: 0,
                  zIndex: 1,
                  borderRadius: "40px",
                }}
              ></Box>
              <img
                src={slider2}
                style={{
                  width: "100%",
                  height: "700px",
                  position: "relative",
                  zIndex: -1,
                  objectFit: "cover",
                  borderRadius: "40px",
                }}
                alt="log home repair and restoration"
              />
              {/* <Container
              sx={{
                maxWidth: { lg: "1450px" },
              }}
            > */}
              <Box sx={style.overText}>
                <Box sx={style.subBox}>
                  <Typography variant="h5" sx={style.welcome}>
                    EXPLORE OUR
                  </Typography>
                  <Reveal>
                    <Typography variant="h3" sx={style.ComName}>
                      SCRAPYARD
                    </Typography>
                  </Reveal>
                </Box>
                <Typography sx={style.para}>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen book.
                </Typography>
                <Button
                  onClick={() => {
                    setValue("SCRAPYARD");
                    navigate(`/category?category=scrapyard&subCategory=`);
                  }}
                  variant="contained"
                  sx={style.button}
                >
                  EXPLORE MORE
                </Button>
              </Box>
              {/* </Container> */}
            </div>
            <div style={{ position: "relative" }}>
              <Box
                sx={{
                  background: "black",
                  opacity: 0.5,
                  position: "absolute",
                  left: 0,
                  right: 0,
                  top: 0,
                  bottom: 0,
                  zIndex: 1,
                  borderRadius: "40px",
                }}
              ></Box>
              <img
                src={slider3}
                style={{
                  width: "100%",
                  height: "700px",
                  position: "relative",
                  zIndex: -1,
                  objectFit: "cover",
                  borderRadius: "40px",
                }}
                alt="log home repair and restoration"
              />
              {/* <Container
              sx={{
                maxWidth: { lg: "1450px" },
              }}
            > */}
              <Box sx={style.overText}>
                <Box sx={style.subBox}>
                  <Typography variant="h5" sx={style.welcome}>
                    EXPLORE OUR
                  </Typography>
                  <Reveal>
                    <Typography variant="h3" sx={style.ComName}>
                      CULTURE HERITAGE
                    </Typography>
                  </Reveal>
                </Box>
                <Typography sx={style.para}>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen book.
                </Typography>
                <Button
                  onClick={() => {
                    setValue("HERITAGE");
                    navigate(`/category?category=heritage&subCategory=`);
                  }}
                  variant="contained"
                  sx={style.button}
                >
                  EXPLORE MORE
                </Button>
              </Box>
              {/* </Container> */}
            </div>
          </Carousel>
        </Container>
      </Box>
      <Box sx={style.smallScreen}>
        <Carousel
          showArrows={true}
          showIndicators={false}
          infiniteLoop={true}
          showThumbs={false}
        >
          <div style={{ position: "relative" }}>
            <Box
              sx={{
                background: "black",
                opacity: 0.6,
                position: "absolute",
                left: 0,
                right: 0,
                top: 0,
                bottom: 0,
                zIndex: 1,
                borderRadius: "40px",
              }}
            ></Box>
            <img
              src={slider1}
              style={{
                width: "100%",
                height: "450px",
                position: "relative",
                zIndex: -1,
                objectFit: "cover",
                borderRadius: "40px",
              }}
              alt="log home repair and restoration"
            />
            {/* <Container
              sx={{
                maxWidth: { lg: "1450px" },
              }}
            > */}
            <Box sx={style.overText}>
              <Box sx={style.subBox}>
                <Typography variant="h5" sx={style.welcome}>
                  EXPLORE OUR
                </Typography>
                <Reveal>
                  <Typography variant="h3" sx={style.ComName}>
                    CREATIVE
                  </Typography>
                </Reveal>
              </Box>
              <Typography sx={style.para}>
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make a type specimen book.
              </Typography>
              <Button variant="contained" sx={style.button}>
                EXPLORE MORE
              </Button>
            </Box>
            {/* </Container> */}
          </div>
          <div style={{ position: "relative" }}>
            <Box
              sx={{
                background: "black",
                opacity: 0.5,
                position: "absolute",
                left: 0,
                right: 0,
                top: 0,
                bottom: 0,
                zIndex: 1,
                borderRadius: "40px",
              }}
            ></Box>
            <img
              src={slider2}
              style={{
                width: "100%",
                height: "450px",
                position: "relative",
                zIndex: -1,
                objectFit: "cover",
                borderRadius: "40px",
              }}
              alt="log home repair and restoration"
            />
            {/* <Container
              sx={{
                maxWidth: { lg: "1450px" },
              }}
            > */}
            <Box sx={style.overText}>
              <Box sx={style.subBox}>
                <Typography variant="h5" sx={style.welcome}>
                  EXPLORE OUR
                </Typography>
                <Reveal>
                  <Typography variant="h3" sx={style.ComName}>
                    SCRAPYARD
                  </Typography>
                </Reveal>
              </Box>
              <Typography sx={style.para}>
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make a type specimen book.
              </Typography>
              <Button variant="contained" sx={style.button}>
                EXPLORE MORE
              </Button>
            </Box>
            {/* </Container> */}
          </div>
          <div style={{ position: "relative" }}>
            <Box
              sx={{
                background: "black",
                opacity: 0.5,
                position: "absolute",
                left: 0,
                right: 0,
                top: 0,
                bottom: 0,
                zIndex: 1,
                borderRadius: "40px",
              }}
            ></Box>
            <img
              src={slider3}
              style={{
                width: "100%",
                height: "450px",
                position: "relative",
                zIndex: -1,
                objectFit: "cover",
                borderRadius: "40px",
              }}
              alt="log home repair and restoration"
            />
            {/* <Container
              sx={{
                maxWidth: { lg: "1450px" },
              }}
            > */}
            <Box sx={style.overText}>
              <Box sx={style.subBox}>
                <Typography variant="h5" sx={style.welcome}>
                  EXPLORE OUR
                </Typography>
                <Reveal>
                  <Typography variant="h3" sx={style.ComName}>
                    CULTURE HERITAGE
                  </Typography>
                </Reveal>
              </Box>
              <Typography sx={style.para}>
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make a type specimen book.
              </Typography>
              <Button variant="contained" sx={style.button}>
                EXPLORE MORE
              </Button>
            </Box>
            {/* </Container> */}
          </div>
        </Carousel>
      </Box>
    </>
  );
}

export default Hero;
