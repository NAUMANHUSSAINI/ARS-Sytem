import React from "react";
import { Box, Container, Typography, Button, Grid } from "@mui/material";
import b1 from "../../Assets/ProductIImages/b1.jpg";
import b2 from "../../Assets/ProductIImages/b2.jpg";
import b3 from "../../Assets/ProductIImages/b3.jpg";
const BlogCard = ({ head, src }) => {
  return (
    <>
      <Box sx={style.card}>
        <Box sx={style.blogImg}>
          <img
            src={src}
            alt="oops"
            style={{
              width: "100%",
              height: "auto",
              objectFit: "cover",
              borderRadius: "15px",
            }}
          />
        </Box>
        <Box sx={style.blogInfo}>
          <Box sx={style.dateInfo}>16 APRIL</Box>
          <Typography sx={style.headings}>{head}</Typography>
          <Typography
            sx={{ fontFamily: "Poppins", textAlign: "left", paddingY: "12px" }}
          >
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. In atque,
            qui cum voluptatem quibusdam dolore veniam....
          </Typography>
          <Button variant="outlined" sx={style.btn}>
            READ MORE
          </Button>
        </Box>
      </Box>
    </>
  );
};

const LatestBlog = () => {
  const blogData = [
    {
      src: b1,
      heading: "Where Trend Going Next",
    },
    {
      src: b2,
      heading: "Ellie Goulding – High For This",
    },
    {
      src: b3,
      heading: "Best Photography of 2024",
    },
  ];
  return (
    <>
      <Box sx={style.mainBox}>
        <Container sx={style.container}>
          <Typography
            sx={style.heading}
            data-aos="fade-up"
            data-aos-delay="500"
          >
            Latest Blogs
          </Typography>
          <Grid container spacing={3}>
            {blogData.map((data, index) => {
              return (
                <React.Fragment key={index}>
                  <Grid item md={4} xs={12}>
                    <BlogCard head={data.heading} src={data.src} />
                  </Grid>
                </React.Fragment>
              );
            })}
          </Grid>
        </Container>
      </Box>
    </>
  );
};

export default LatestBlog;
const style = {
  mainBox: {
    paddingY: "2rem",
  },
  container: {
    maxWidth: { lg: "1450px" },
  },
  heading: {
    fontSize: "40px",
    fontFamily: "Poppins",
    paddingY: "2rem",
    fontWeight: 700,
  },
  btn: {
    paddingX: "20px",
    fontWeight: 600,
    fontFamily: "Poppins",
    fontSize: "13px",
    border: "1px solid black",
    borderRadius: "5px",
    transition: "all ease-out 0.5s",
    color: "black",
    opacity: 0.8,
    alignSelf: "start",
    // backgroundColor: "white",
    boxShadow: 1,
    ":hover": {
      backgroundColor: "black",
      border: "1px solid black",
      color: "white",
    },
  },
  card: {
    padding: "10px",
    borderRadius: "15px",
    backgroundColor: "white",
    boxShadow: 4,
    position: "relative",
  },
  blogImg: {
    overflow: "hidden",
    position: "relative",
    display: "block",
  },
  blogInfo: {
    padding: "20px 20px 30px",
    border: "1px solid #eee",
    boxShadow: "0px 3px 7px rgba(0, 0, 0, 0.12)",
    display: "flex",
    flexDirection: "column",
    alignItems: "start",
  },
  dateInfo: {
    position: "absolute",
    width: "75px",
    height: "35px",
    background: "#ef8031",
    display: "inline-block",
    color: "#fff",
    fontWeight: 700,
    fontSize: "12px",
    textTransform: "uppercase",
    textAlign: "center",
    left: "30px",
    marginTop: "-45px",
    lineHeight: "35px",
    border: "2px solid #fff",
  },
  headings: {
    fontSize: "1.4em",
    fontFamily: "Poppins",
    fontWeight: 700,
    textAlign: "left", // This corresponds to 16px (assuming default browser font size of 16px)
  },
};
