import { createSlice } from "@reduxjs/toolkit";

const cartSlice = createSlice({
  name: "cart",
  initialState: {
    cart: [],
    total: 0,
  },
  reducers: {
    addToCart: (state, action) => {
      const product = action.payload;
      const existingProduct = state.cart.find((item) => item.id === product.id);

      if (existingProduct) {
        existingProduct.quantity += 1;
      } else {
        state.cart.push({ ...product, quantity: 1 });
      }
    },
    removeFromCart: (state, action) => {
      console.log(action.payload.id, "action.payload.id");
      state.cart = state.cart.filter(
        (product) => product.id !== action.payload.id
      );
    },
    updateCart: (state, action) => {
      const { id, quantity } = action.payload;
      const productIndex = state.cart.findIndex((product) => product.id === id);

      if (productIndex !== -1) {
        if (quantity > 0) {
          state.cart[productIndex].quantity = quantity;
        } else {
          state.cart = state.cart.filter((product) => product.id !== id);
        }
      }
    },
    clearCart: (state) => {
      state.cart = [];
    },
    calculateTotal: (state) => {
      state.total = state.cart.reduce((acc, item) => {
        const itemPrice = item.item?.post?.price;
        const itemQuantity = item.quantity;
        if (itemPrice) {
          return acc + Number(itemPrice) * itemQuantity;
        } else {
          console.error(`Item ${item.uid} is missing price data.`);
          return acc;
        }
      }, 0);
    },
  },
});

export const {
  addToCart,
  removeFromCart,
  updateCart,
  clearCart,
  calculateTotal,
} = cartSlice.actions;

export default cartSlice.reducer;
