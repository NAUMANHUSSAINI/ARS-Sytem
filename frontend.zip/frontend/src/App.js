import logo from "./logo.svg";
import "./App.css";
import {
  createBrowserRouter,
  RouterProvider,
  createRoutesFromElements,
  Route,
} from "react-router-dom";
import Home from "../src/Pages/Home";
import { About } from "../src/Pages/About/About";
import Trainee from '.src/Pages/Trainee/Trainee';
import AOS from "aos";
import "aos/dist/aos.css";
import { useEffect } from "react";
import ContactUs from "./Pages/Contact/ContactUs";
import { MyContextProvider } from "./Context/userContext";
import Category from "./Pages/Category/Category";
import Single from "./Pages/SingleProduct/Single";
import Cart from "./Pages/AddToCart/Cart";
import Login from "./Pages/Auth/Login";
import Register from "./Pages/Auth/Register";
import UserAdsListing from "./Pages/UserDashboard/UserAdsListing";
import UserCreatePost from "./Pages/UserDashboard/UserCreatePost";
import Success from "./Pages/Success/Success";
import UserOrderListing from "./Pages/UserDashboard/UserOrderListing";

function App() {
  // Main Routes
  const mainRoutes = createBrowserRouter(
    createRoutesFromElements(
      <Route>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/trainee" component={Trainee} /> 
        <Route path="/contact" element={<ContactUs />} />
        <Route path="/category" element={<Category />} />
        <Route path="/singleProduct" element={<Single />} />
        <Route path="/user-cart" element={<Cart />} />
        <Route path="/success" element={<Success />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/dashboard/user-ads-listings"
          element={<UserAdsListing />}
        />
        <Route path="/dashboard/orders" element={<UserOrderListing />} />
        <Route path="/dashboard/create-post" element={<UserCreatePost />} />
      </Route>
    )
  );

  useEffect(() => {
    AOS.init();
  }, []);
  return (
    <MyContextProvider>
      <div className="App">
        <RouterProvider router={mainRoutes} />
      </div>
    </MyContextProvider>
  );
}

export default App;
