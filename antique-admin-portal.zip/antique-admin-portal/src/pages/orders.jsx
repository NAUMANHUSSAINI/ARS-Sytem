import React from 'react';
import { Helmet } from 'react-helmet-async';
import Orders from 'src/sections/Orders/Orders';

const orders = () => {
  return (
    <>
      <Helmet>
        <title> Products </title>
      </Helmet>
      <Orders />
    </>
  );
};

export default orders;
