// ----------------------------------------------------------------------

export const account = {
  displayName: 'Antique Review',
  email: 'admin@admin.com',
  photoURL: '/assets/images/avatars/avatar_25.jpg',
};
