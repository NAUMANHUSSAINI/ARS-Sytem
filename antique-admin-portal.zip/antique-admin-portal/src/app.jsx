/* eslint-disable perfectionist/sort-imports */
import { useState, useEffect } from 'react';
import 'src/global.css';

import { useScrollToTop } from 'src/hooks/use-scroll-to-top';

import { Router, AuthRouter } from 'src/routes/sections';
import ThemeProvider from 'src/theme';
import { useUserContext } from './Context/UserContext';

// ----------------------------------------------------------------------

export default function App() {
  useScrollToTop();
  const { user } = useUserContext();

  return <ThemeProvider>{user ? <Router /> : <AuthRouter />}</ThemeProvider>;
}
