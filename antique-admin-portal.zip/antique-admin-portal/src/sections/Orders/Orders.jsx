import {
  Box,
  Container,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  Typography,
} from '@mui/material';
import React, { useEffect, useState } from 'react';
import { getAllOrders, updateOrderStatus } from 'src/Services/Dashboard';
import { Timestamp } from 'firebase/firestore';
import toast from 'react-hot-toast';

const Orders = () => {
  const [orders, setOrders] = useState();

  const handleStatusChange = async (event, id) => {
    if (id) {
      let changed = await updateOrderStatus(id, event.target.value);
      if (changed) {
        toast.success('Status Updated');
        getAllOrders().then((data) => {
          setOrders(data);
        });
      }
    }
  };
  useEffect(() => {
    getAllOrders().then((data) => {
      setOrders(data);
    });
  }, []);
  return (
    <>
      <Container>
        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
          <Typography variant="h3">Orders</Typography>
        </Stack>
        <Box sx={style.tableBox}>
          <Grid
            container
            sx={{
              background: 'linear-gradient(to right, #fc4a1a, #f7b733)',
              alignItems: 'center',
              justifyContent: 'space-around',
              display: 'flex',
              borderRadius: '10px',
            }}
          >
            <Grid item md={2}>
              <Typography sx={style.heading}>Order Date</Typography>
            </Grid>
            <Grid item md={2}>
              <Typography sx={style.heading}>Order #</Typography>
            </Grid>

            <Grid item md={2}>
              <Typography sx={style.heading}>Quantity</Typography>
            </Grid>
            <Grid item md={2}>
              <Typography sx={style.heading}>Total</Typography>
            </Grid>
            <Grid item md={2}>
              <Typography sx={style.heading}>Status</Typography>
            </Grid>
          </Grid>
          {orders &&
            orders?.length > 0 &&
            orders?.map((data, index) => {
              const createdAtDate =
                data?.createdAt instanceof Timestamp
                  ? data.createdAt.toDate()
                  : new Date(data?.createdAt);

              let totalQuantity = 0;
              data?.items?.map((ite) => {
                totalQuantity += ite?.quantity;
              });
              return (
                <>
                  <Grid
                    container
                    key={index}
                    sx={{
                      background: 'linear-gradient(to right, #fc4a1a, #f7b733)',
                      alignItems: 'center',
                      justifyContent: 'space-around',
                      display: 'flex',
                      borderRadius: '10px',
                      marginY: '10px',
                      paddingY: '10px',
                    }}
                  >
                    <Grid item md={2}>
                      {createdAtDate.toDateString()}
                    </Grid>
                    <Grid item md={2}>
                      # {data?.orderId}
                    </Grid>
                    <Grid item md={2}>
                      {totalQuantity}
                    </Grid>
                    <Grid item md={2}>
                      {data?.total} /-
                    </Grid>
                    <Grid item md={2}>
                      <FormControl fullWidth>
                        <InputLabel id="demo-simple-select-label">Status</InputLabel>
                        <Select
                          labelId="demo-simple-select-label"
                          id="demo-simple-select"
                          value={data?.shippingStatus}
                          label="Status"
                          onChange={(e) => handleStatusChange(e, data?.id)}
                        >
                          <MenuItem value={'placed'}>Placed</MenuItem>
                          <MenuItem value={'shipping'}>Shipping</MenuItem>
                          <MenuItem value={'completed'}>Completed</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                  </Grid>
                </>
              );
            })}
        </Box>
      </Container>
    </>
  );
};

export default Orders;
const style = {
  tableBox: {
    width: '100%',
    marginY: '20px',
  },
  heading: {
    paddingY: '12px',
    color: 'white',
    fontWeight: '600',
  },
};
