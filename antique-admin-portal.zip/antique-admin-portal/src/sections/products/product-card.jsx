import PropTypes from 'prop-types';

import Box from '@mui/material/Box';
import Link from '@mui/material/Link';
import Card from '@mui/material/Card';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';

import { fCurrency } from 'src/utils/format-number';

import Label from 'src/components/label';
import { FormControl, InputLabel, MenuItem, Select } from '@mui/material';

export default function ShopProductCard({ product, handleChange }) {
  const renderStatus = (
    <Label
      variant="filled"
      color={
        product.item.post.status === 'rejected'
          ? 'error'
          : product.item.post.status === 'pending'
          ? 'info'
          : 'info'
      }
      sx={{
        zIndex: 9,
        top: 16,
        right: 16,
        position: 'absolute',
        textTransform: 'uppercase',
      }}
    >
      {product.item.post.status}
    </Label>
  );

  const renderImg = (
    <Box
      component="img"
      alt={product.item.post.title}
      src={product.item.imageUrls[0]}
      sx={{
        top: 0,
        width: 1,
        height: 1,
        objectFit: 'cover',
        position: 'absolute',
      }}
    />
  );

  const renderPrice = <Typography variant="subtitle1">PKR.{product.item.post.price}</Typography>;

  return (
    <Card>
      <Box sx={{ pt: '100%', position: 'relative' }}>
        {product.item.post.status && renderStatus}

        {renderImg}
      </Box>

      <Stack spacing={2} sx={{ p: 3 }}>
        <Link color="inherit" underline="hover" variant="subtitle2" noWrap>
          {product.item.post.title}
        </Link>

        <Stack direction="row" alignItems="center" justifyContent="space-between">
          {/* <ColorPreview colors={product.colors} /> */}
          <FormControl sx={{ minWidth: 90, height: '50px' }}>
            <Select
              labelId="demo-simple-select-error-label"
              id="demo-simple-select-error"
              label=""
              value={product.item.post.status}
              onChange={(e) => handleChange(e.target.value, product.id)}
            >
              <MenuItem value={'pending'}>pending</MenuItem>
              <MenuItem value={'approve'}>approve</MenuItem>
              <MenuItem value={'rejected'}>rejected</MenuItem>
            </Select>
          </FormControl>
          {renderPrice}
        </Stack>
      </Stack>
    </Card>
  );
}

ShopProductCard.propTypes = {
  product: PropTypes.object,
};
