import { useEffect, useState } from 'react';

import Container from '@mui/material/Container';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';

import ProductCard from '../product-card';
import { getAllproducts, updateProductById } from 'src/Services/Dashboard';
import { CircularProgress } from '@mui/material';

export default function ProductsView() {
  const [products, setProducts] = useState();
  const handleChange = (val, id) => {
    updateProductById(val, id).then(() => {
      getAllproducts().then((data) => {
        setProducts(data);
      });
    });
  };
  useEffect(() => {
    getAllproducts().then((data) => {
      setProducts(data);
    });
  }, []);
  return (
    <Container>
      <Typography variant="h4" sx={{ mb: 5 }}>
        Products
      </Typography>

      <Grid container spacing={3}>
        {products && products.length > 0 ? (
          products.map((product, index) => (
            <Grid key={index} xs={12} sm={6} md={3}>
              <ProductCard product={product} handleChange={handleChange} />
            </Grid>
          ))
        ) : (
          <CircularProgress color="secondary" />
        )}
      </Grid>
    </Container>
  );
}
