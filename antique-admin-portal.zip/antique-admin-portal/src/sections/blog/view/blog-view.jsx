import Stack from '@mui/material/Stack';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import { getDownloadURL, ref, uploadBytes } from 'firebase/storage';
import { storage } from 'src/Config/Config';
import { useRef, useState } from 'react';
import { Box, Button } from '@mui/material';
import {
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import Iconify from 'src/components/iconify';
import toast from 'react-hot-toast';
import { CreatePost } from 'src/Services/Dashboard';

// ----------------------------------------------------------------------
const subcategories = {
  Scrapyard: [
    'Scrap Metal Recycling',
    'Junkyard Finds',
    'Vehicle Salvage',
    'Metal Scrapping',
    'Recycled Auto Parts',
    'Industrial Waste Management',
    'E-Waste Disposal',
    'Scrap Electronics Recycling',
    'Steel Scrap Processing',
    'Waste Material Recovery',
  ],
  Creative: [
    'Visual Arts',
    'Craft Making',
    'Graphic Design',
    'Digital Illustration',
    'Photography',
    'Creative Writing',
    'Music Composition',
    'Film Production',
    'Performing Arts',
    'Art Therapy',
  ],
  Culture: ['Sindhi', 'Islamabadi', 'Quettawal', 'Balochi', 'Marwati'],
};
const inital = {
  price: '',
  title: '',
  desc: '',
  city: '',
  zip: '',
  category: '',
  subCategory: '',
  status: 'approve',
};
const cities = [
  'Karachi',
  'Lahore',
  'Islamabad',
  'Rawalpindi',
  'Quetta',
  'Peshawar',
  'Faisalabad',
  'Multan',
  'Hyderabad',
  'Sialkot',
  'Gujranwala',
  'Sargodha',
  'Bahawalpur',
  'Sukkur',
  'Larkana',
];

export default function BlogView() {
  const inputRef = useRef();
  const navigate = useNavigate();
  const [alignment, setAlignment] = useState('Scrapyard');
  const [imageUrls, setImageUrls] = useState([]);
  const [post, setPost] = useState(inital);
  const handleFileChange = async (event) => {
    const files = event.target.files;
    const promises = [];
    const urls = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const storageRef = ref(storage, `images/${file.name}`);
      const uploadTask = uploadBytes(storageRef, file)
        .then(async () => {
          const downloadURL = await getDownloadURL(storageRef);
          urls.push(downloadURL);
        })
        .catch((error) => {
          console.error('Error uploading file:', error);
        });

      promises.push(uploadTask);
    }

    await Promise.all(promises);
    setImageUrls(urls);
  };
  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
    setPost((prev) => ({
      ...prev,
      category: newAlignment,
      subCategory: '',
    }));
  };
  const postFeildsChange = (val, key) => {
    setPost((prev) => ({
      ...prev,
      [key]: val,
    }));
  };
  const handleSubcategoryChange = (event) => {
    setPost((prev) => ({
      ...prev,
      subCategory: event.target.value,
    }));
  };
  const submit = () => {
    const { price, title, desc, city, zip, category, subCategory } = post;
    if (
      !price ||
      !title ||
      !desc ||
      !city ||
      !zip ||
      !category ||
      !subCategory ||
      imageUrls.length === 0
    ) {
      toast.error('All fields are required.');
      return;
    } else {
      let temp = {
        post,
        imageUrls,
      };
      CreatePost(temp, 'admin')
        .then(() => {
          toast.success('Product Added');
          setPost(inital);
          setImageUrls([]);
          navigate('/');
        })
        .catch((err) => {
          console.log(err);
          toast.error('Something Went Wrong');
        });
    }
  };
  return (
    <Container>
      <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
        <Typography variant="h4">Add Product</Typography>
        <Button
          onClick={submit}
          variant="contained"
          color="inherit"
          startIcon={<Iconify icon="eva:plus-fill" />}
        >
          Add Product
        </Button>
      </Stack>

      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Box
            sx={{
              width: '100%',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'start',
            }}
          >
            <Typography sx={style.heading1}>Upload Product Media :</Typography>
            <label className="picture" for="picture__input" tabIndex="0">
              <span
                className="picture__image"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                }}
              >
                {' '}
                Upload Image
              </span>
            </label>

            <input
              ref={inputRef}
              type="file"
              name="picture__input"
              id="picture__input"
              accept="image/*"
              onChange={handleFileChange}
              multiple
            />
          </Box>
          <Box
            sx={{
              width: '100%',
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              gap: '12px',
              marginY: '1rem',
            }}
          >
            {imageUrls &&
              imageUrls.length > 0 &&
              imageUrls.map((data, index) => {
                return (
                  <>
                    <img
                      src={data}
                      alt="oops"
                      key={index}
                      style={{
                        width: '150px',
                        height: '150px',
                        objectFit: 'cover',
                        borderRadius: '10px',
                      }}
                    />
                  </>
                );
              })}
          </Box>
        </Grid>
        <Grid item lg={6}>
          <Box
            sx={{
              width: '100%',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'start',
            }}
          >
            <Typography sx={style.heading1}>Product Information :</Typography>
            <Typography sx={style.label}>Select Category</Typography>
            <ToggleButtonGroup
              value={alignment}
              exclusive
              onChange={handleChange}
              aria-label="Platform"
              sx={{ marginBottom: '20px', color: 'white' }}
            >
              <ToggleButton sx={{ color: 'grey' }} value="Scrapyard">
                Scrapyard
              </ToggleButton>
              <ToggleButton sx={{ color: 'grey' }} value="Culture">
                Culture Heritage
              </ToggleButton>
              <ToggleButton sx={{ color: 'grey' }} value="Creative">
                Creative
              </ToggleButton>
            </ToggleButtonGroup>

            {alignment && (
              <FormControl variant="outlined" sx={style.feild}>
                <InputLabel id="subcategory-select-label">Select Sub Category</InputLabel>
                <Select
                  labelId="subcategory-select-label"
                  value={post.subCategory}
                  onChange={handleSubcategoryChange}
                  label="Subcategory"
                >
                  {subcategories[alignment].map((subcategory, index) => (
                    <MenuItem key={index} value={subcategory}>
                      {subcategory}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}
            <TextField
              sx={style.feild}
              id="outlined-basic"
              label="Price"
              variant="outlined"
              value={post.price}
              onChange={(e) => {
                postFeildsChange(e.target.value, 'price');
              }}
            />
          </Box>
        </Grid>
        <Grid item lg={6}>
          <TextField
            id="outlined-basic"
            label="Title"
            variant="outlined"
            sx={style.feild}
            value={post.title}
            onChange={(e) => {
              postFeildsChange(e.target.value, 'title');
            }}
          />
          <TextField
            id="outlined-basic"
            label="Description"
            variant="outlined"
            multiline
            sx={style.feild}
            value={post.desc}
            onChange={(e) => {
              postFeildsChange(e.target.value, 'desc');
            }}
          />
          <TextField
            id="outlined-basic"
            label="ZIP Code"
            variant="outlined"
            multiline
            sx={style.feild}
            value={post.zip}
            onChange={(e) => {
              postFeildsChange(e.target.value, 'zip');
            }}
          />
          <FormControl variant="outlined" sx={style.feild}>
            <InputLabel id="city-select-label">City</InputLabel>
            <Select
              labelId="city-select-label"
              id="city-select"
              value={post.city}
              onChange={(e) => postFeildsChange(e.target.value, 'city')}
              label="City"
            >
              {cities.map((city, index) => (
                <MenuItem key={index} value={city}>
                  {city}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
      </Grid>
    </Container>
  );
}
const style = {
  heading1: {
    fontWeight: 600,
    marginBottom: '25px',
    fontSize: '20px',
  },
  label: {
    fontWeight: 600,
  },
  feild: {
    marginY: '10px',
    width: '500px',
  },
};
