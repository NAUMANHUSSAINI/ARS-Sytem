import { addDoc, collection, doc, getDocs, orderBy, query, updateDoc } from 'firebase/firestore';
import { db } from 'src/Config/Config';

export const getTotals = async () => {
  let totalOrders = 0;
  let completedOrders = 0;
  let shippedOrders = 0;
  let placedOrders = 0;
  let totalUsers = 0;

  const querySnapshot = await getDocs(collection(db, 'Orders'));
  querySnapshot.forEach((doc) => {
    let o = doc.data();
    totalOrders += 1;
    if (o.shippingStatus === 'placed') {
      placedOrders += 1;
    } else if (o.shippingStatus === 'completed') {
      completedOrders += 1;
    } else if (o.shippingStatus === 'shipping') {
      shippedOrders += 1;
    }
  });

  const querySnapshotUser = await getDocs(collection(db, 'users'));
  querySnapshotUser.forEach((doc) => {
    totalUsers += 1;
  });

  return { totalOrders, completedOrders, shippedOrders, placedOrders, totalUsers };
};

export const getAllUsers = async () => {
  let temp = [];
  const querySnapshotUser = await getDocs(collection(db, 'users'));
  querySnapshotUser.forEach((doc) => {
    temp.push({ ...doc.data(), id: doc.id });
  });
  return temp;
};

export const getAllproducts = async () => {
  let temp = [];
  try {
    const querySnapshotUser = await getDocs(collection(db, 'Posts'));
    querySnapshotUser.forEach((doc) => {
      temp.push({ ...doc.data(), id: doc.id });
    });
    const statusOrder = { pending: 1, approve: 2, rejected: 3 };
    temp.sort((a, b) => statusOrder[a.item.post.status] - statusOrder[b.item.post.status]);
    return temp;
  } catch (err) {
    console.error('Error creating order:', err);
    return { error: err.message };
  }
};
export const getAllOrders = async () => {
  let temp = [];
  try {
    const querySnapshotUser = await getDocs(collection(db, 'Orders'));
    querySnapshotUser.forEach((doc) => {
      temp.push({ ...doc.data(), id: doc.id });
    });

    return temp;
  } catch (err) {
    console.error('Error creating order:', err);
    return { error: err.message };
  }
};

export const updateProductById = async (status, id) => {
  try {
    const productRef = doc(db, 'Posts', id); // Adjust the collection name accordingly
    await updateDoc(productRef, {
      'item.post.status': status,
    });
    console.log(`Product ${id} updated successfully`);
  } catch (error) {
    console.error('Error updating product: ', error);
  }
};
export const CreatePost = async (item, postId) => {
  await addDoc(collection(db, 'Posts'), { item, uid: postId });
};

export const updateOrderStatus = async (id, status) => {
  try {
    const orderRef = doc(db, 'Orders', id);
    await updateDoc(orderRef, {
      shippingStatus: status,
    });
    return true;
  } catch (error) {
    return false;
  }
};
