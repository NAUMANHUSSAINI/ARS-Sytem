import { initializeApp } from 'firebase/app';
import { getStorage } from 'firebase/storage';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
const firebaseConfig = {
  apiKey: 'AIzaSyBJT520kpUCRiG5YpZrMR3l5DoIqOrXqnA',
  authDomain: 'antiquereviewsystem.firebaseapp.com',
  projectId: 'antiquereviewsystem',
  storageBucket: 'antiquereviewsystem.appspot.com',
  messagingSenderId: '271738309288',
  appId: '1:271738309288:web:47893d52197f1c0b54909d',
  measurementId: 'G-NPRSKNEMCF',
};

export const app = initializeApp(firebaseConfig);
export const storage = getStorage(app);
export const db = getFirestore(app);
export const auth = getAuth(app);
